from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,xml.etree.ElementTree as ET
import numpy as np
from tests.validation.common import read_owned,digest,current_sources
from tests.validation.reference_mesh import verify_surface
from tests.validation.reference_transfinite import shape_statistics

root=Path('artifacts/validation');names=['fixed-asset-preflight-001','fixed-asset-preflight-002'];contract='validation/fixed-asset-preflight-controls.json'
r,a=read_owned(root/(names[1]+'.json'),digest(contract),'fixed-seed-asset-preflight');current_sources(r,tuple(r['producer_sha256']))
assert r['complete'] and r['assets_usable'] and not r['passed'] and not r['full_reference_qualified']
assert r['fresh_ainf_export_required'] and r['native_evaluations']==r['new_bem_solves']==0
assert r['elapsed_seconds']<=60 and r['accounted_disk_upper_bytes']<2*1024**3
failed=json.loads((root/(names[0]+'.json')).read_text());assert not failed['complete'] and not failed['passed'] and failed['error']['type']=='AttributeError'
assert digest(root/(names[0]+'.npz'))==failed['arrays_sha256']
for name,h in failed['producer_sha256'].items():assert digest(root/(names[0]+'.source')/name)==h
assert digest(root/(names[0]+'.source/contract.json'))==failed['contract_sha256']
for row in r['levels']:
    mesh=a[f"reference_triangles_{row['level']}"]
    assert verify_surface(a['wetted_triangles'],mesh)==row['geometry'] and shape_statistics(mesh)==row['quality']
external=[]
for role,file in [('frozen','frozen-fixed-001.zip'),('raw','reference-study-003.zip'),('sources','periodic-sources-003.zip')]:
    item=dict(argument=role,filename=file,sha256=r['bundle_sha256'][role],copy_to=['validation/'+name+'.source/'+role+'.zip' for name in names])
    for logical in item['copy_to']:assert digest(Path('artifacts')/logical)==item['sha256']
    external.append(item)
restore='''from pathlib import Path
from hashlib import sha256
import argparse,json,shutil
p=argparse.ArgumentParser()
for name in ('frozen','raw','sources'):p.add_argument('--'+name+'-bundle',type=Path,required=True)
args=p.parse_args();root=Path(__file__).resolve().parent
for item in json.loads((root/'external-inputs.json').read_text()):
    source=getattr(args,item['argument']+'_bundle');assert sha256(source.read_bytes()).hexdigest()==item['sha256']
    for entry in item['copy_to']:
        out=(root/entry).resolve();assert out.is_relative_to(root);out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,out)
print('Both actual producer attempts and all exact input graphs restored; failed reader attempt preserved.')
'''
junit=Path('artifacts/pytest-fixed-assets-all-003.xml');suites=ET.parse(junit).findall('.//testsuite');checks={key:sum(int(x.attrib.get(key,0)) for x in suites) for key in ('tests','failures','errors','skipped')};assert checks==dict(tests=287,failures=0,errors=0,skipped=0)
bundle=Path('validation/evidence/fixed-asset-preflight-001.zip');assert not bundle.exists();skip={entry for item in external for entry in item['copy_to']}
with ZipFile(bundle,'x',ZIP_DEFLATED) as z:
    for name in names:
        for suffix in ('.json','.npz'):z.write(root/(name+suffix),'validation/'+name+suffix)
        archive=root/(name+'.source')
        for file in sorted(archive.rglob('*')):
            if not file.is_file():continue
            entry='validation/'+name+'.source/'+file.relative_to(archive).as_posix()
            if entry not in skip:z.write(file,entry)
    z.writestr('external-inputs.json',json.dumps(external,indent=2)+'\n');z.writestr('restore_inputs.py',restore)
    z.writestr('README.txt','Both failed reader001 and corrected002 actual graphs are retained. After extraction run python restore_inputs.py --frozen-bundle PATH --raw-bundle PATH --sources-bundle PATH with tracked frozen-fixed001/reference-study003/periodic-sources003. Asset/geometry admission only: all original physical gates stay failed.\n')
    z.write(junit,'checks/'+junit.name);z.write(__file__,'pack_fixed_assets.py')
summary={key:r[key] for key in ('current_commit','complete','passed','assets_usable','fresh_ainf_export_required','full_run_authorized','full_reference_qualified','source_discretization_qualified','native_evaluations','new_bem_solves','current_physical_arrays_bitwise_equal','current_input_json_bytes_equal','source_inventory','seed_quality','levels','common_output_grids','work_inventory','source_export_workspace_plan','memory_records','accounted_disk_upper_bytes','elapsed_seconds','decision','historical_commits','green_identity')}
summary.update(bundle_sha256=digest(bundle),external_inputs=external,tests=checks,preserved_reader_failure={key:failed.get(key) for key in ('current_commit','complete','passed','error')})
bundle.with_name('fixed-asset-preflight-001-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(bundle=str(bundle),bytes=bundle.stat().st_size,sha256=summary['bundle_sha256']),indent=2))
