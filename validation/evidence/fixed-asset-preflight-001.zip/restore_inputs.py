from pathlib import Path
from hashlib import sha256
import argparse,json,shutil
p=argparse.ArgumentParser()
for name in ('frozen','raw','sources'):p.add_argument('--'+name+'-bundle',type=Path,required=True)
args=p.parse_args();root=Path(__file__).resolve().parent
for item in json.loads((root/'external-inputs.json').read_text()):
    source=getattr(args,item['argument']+'_bundle');assert sha256(source.read_bytes()).hexdigest()==item['sha256']
    for entry in item['copy_to']:
        out=(root/entry).resolve();assert out.is_relative_to(root);out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,out)
print('Both actual producer attempts and all exact input graphs restored; failed reader attempt preserved.')
