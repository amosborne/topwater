After extraction run python restore_shared_inputs.py to restore exact shared input paths with SHA verification. All pressure stabilization/reference qualification remains false.
