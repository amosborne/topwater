"""Exact cell accounting of matrix increments, not a continuum error estimator."""
from pathlib import Path
import json,shutil
import numpy as np
from topwater.rankine import TrianglePanels
from tests.validation.common import prepare,save,read_owned,digest,current_sources
from tests.validation.paired_body import scaled_check

source=Path('artifacts/validation/paired-body-study-002.json')
output=Path('artifacts/validation/paired-body-localization-001.json')
contract=Path('validation/paired-body-controls.json');c=json.loads(contract.read_text())
r,a=read_owned(source,digest(contract),'paired-body-study')
current_sources(r,tuple(r['producer_sha256']))
report=prepare(output,contract,'paired-body-increment-localization');out={}
archive=output.with_suffix('.source')
relative=Path(__file__).resolve().relative_to(Path.cwd());target=archive/relative
target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(relative,target)
report['producer_sha256'][relative.as_posix()]=digest(relative)
for suffix in ('.json','.npz'):shutil.copyfile(source.with_suffix(suffix),archive/('study'+suffix))
shutil.copyfile(source.with_suffix('.source')/'inputs.json',archive/'inputs.json')
shutil.copyfile(source.with_suffix('.source')/'parent.zip',archive/'parent.zip')
report.update(study_manifest_sha256=digest(source),study_arrays_sha256=digest(source.with_suffix('.npz')),
    input_sha256=digest(archive/'inputs.json'),parent_bundle_sha256=r['parent_bundle_sha256'],
    full_reference_qualified=False,scope=__doc__,diagnostics=[])
save(output,report,out)
rho=c['density_kg_m3'];scale=np.sqrt(a['dry_mass'].diagonal()[:,None]*a['dry_mass'].diagonal()[None,:])
failed=a['reference_previous_failed']|a['reference_latest_failed']|a['reference_trend_failed']
allow=c['reference_absolute_normalized']+c['reference_relative']*abs(a['capytaine_Ainf'][-1]/scale)
edges=np.array([0.,.002,.01,.03,.1,np.inf]);report['vertical_depth_band_edges_m']=[0.,.002,.01,.03,.1,'infinity']
for method,matrix_key,field_key in [('capytaine','capytaine_Ainf','capytaine_aux'),('topwater','topwater_Ainf','topwater_aux')]:
    for level in (1,2,3):
        p=TrianglePanels(a[f'triangles_{level}'],-1);n=len(p.areas);half=n//8
        parent=np.r_[np.tile(np.arange(half),4),np.tile(np.arange(half),4)+half]
        if len(parent)!=n:raise ValueError('unexpected frozen child-parent layout')
        N=np.c_[p.normals,np.cross(p.centroids-a['world_cg'],p.normals)]
        delta=a[f'{field_key}_{level}']-a[f'{field_key}_{level-1}'][parent]
        contributions=rho*np.einsum('ni,nj,n->nij',N,delta,p.areas)
        expected=a[matrix_key][level]-a[matrix_key][level-1]
        ratio=scaled_check(contributions.sum(axis=0),expected,scale,c['trace_scaled_tolerance'])
        score=abs(contributions/scale/allow)[:,failed].sum(axis=1)
        total=float(score.sum());area=float(p.areas.sum())
        depth=np.maximum(0.,-p.centroids[:,2]);bands=np.searchsorted(edges,depth,side='right')-1
        aspects=p.edge_lengths.max(axis=1)**2/(2*p.areas);sliver=aspects>1000
        prefix=f'{method}_{level}_';out[prefix+'cell_matrix_increment']=contributions
        out[prefix+'failed_entry_weighted_score']=score;out[prefix+'depth_band']=bands
        out[prefix+'aspect_indicator']=aspects
        band_scores=[float(score[bands==i].sum()/total) if total else 0. for i in range(5)]
        band_areas=[float(p.areas[bands==i].sum()/area) for i in range(5)]
        out[prefix+'band_matrix_increment']=np.stack([contributions[bands==i].sum(axis=0) for i in range(5)])
        report['diagnostics'].append(dict(method=method,level=level,reconstruction_ratio=ratio,
            failed_entry_score_fraction_by_depth=band_scores,area_fraction_by_depth=band_areas,
            aspect_over_1000_panel_fraction=float(sliver.mean()),aspect_over_1000_area_fraction=float(p.areas[sliver].sum()/area),
            aspect_over_1000_score_fraction=float(score[sliver].sum()/total) if total else 0.))
report.update(complete=True,passed=False,interpretation='Exact redistribution of measured refinement increments only; no continuum/local error bound or qualified reference follows')
save(output,report,out)
print(json.dumps(report['diagnostics'],indent=2))
