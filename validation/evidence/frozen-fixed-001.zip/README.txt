Geometry/control evidence only; the hydrodynamic reference remains unqualified.
Extract this archive into artifacts/ in the matching repository/source checkpoint.
Extract geometry-candidate.zip into artifacts/ as well to reproduce the adoption proof.
The proof verifier is validation/verify-fixed-freeze-001.py. Run from repository root via Python stdin (so root is on sys.path), with --frozen artifacts/validation/frozen-fixed-001.json --preflight artifacts/validation/transfinite-preflight-002.json --physical-reference artifacts/validation/transfinite-preflight-002.source/physical-reference.json --output <a fresh proof JSON>.
Current source bytes must match the archived producer hashes.
No hydrodynamic solve is part of the verifier.
