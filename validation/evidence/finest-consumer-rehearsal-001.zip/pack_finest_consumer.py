from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED,ZIP_STORED
import json,xml.etree.ElementTree as ET
import numpy as np
from tests.validation.common import read_owned,digest,current_sources
from tests.validation.finest_cost_probe import owned_zip
from tests.validation.finest_consumer import stream_hash
from tests.validation.frozen_source_quadrature import pressure_matrix
from tests.validation.paired_body import scaled_check

root=Path('artifacts/validation');stem='finest-consumer-rehearsal-001';path=root/(stem+'.json')
r,a=read_owned(path,digest('validation/finest-consumer-rehearsal-controls.json'),'finest-consumer-resource-rehearsal');current_sources(r,tuple(r['producer_sha256']))
assert r['complete'] and r['rehearsal_passed'] and r['resource_only'] and r['synthetic_fields'] and not r['passed']
assert not r['full_run_authorized'] and not r['full_reference_qualified'] and r['elapsed_seconds']<=60
assert r['completed_stages']==['inputs','native','checkpoint12','checkpoint16','checkpoint20','final_checkpoint','array_verification','package_verification']
assert max(r['latest_memory'][key] for key in ('peak_working_set_bytes','peak_committed_bytes'))<=2*1024**3
assert r['accounted_additional_disk_upper_bytes']<=2*1024**3 and path.stat().st_size<65536
archive=path.with_suffix('.source');common,ca=owned_zip(archive/'common.zip','common-output-sources-001','common-output-source-diagnostic',digest('validation/common-output-source-controls.json'),
    ['dry_mass','source_A','source_latest_increment','latest_quadrature_charge']+[f'target_{order}_{name}' for order in (12,16,20) for name in ('points','owners','weights','normal')])
scale=np.sqrt(a['dry_mass'].diagonal()[:,None]*a['dry_mass'].diagonal()[None,:]);ratios=[]
for order in (12,16,20):
    prefix=f'order_{order}_';key=f'target_{order}_';field=a[prefix+'potential'];rng=np.random.default_rng(24000+order)
    for start in range(0,len(field),100):
        end=min(start+100,len(field));np.testing.assert_array_equal(field[start:end].real,rng.standard_normal((end-start,6)));np.testing.assert_array_equal(field[start:end].imag,rng.standard_normal((end-start,6)))
    for name in ('points','owners','weights','normal'):np.testing.assert_array_equal(a[key+name],ca[key+name])
    matrix=pressure_matrix(a[key+'points'],a[key+'normal'],a[key+'weights'],field,a['world_cg'],1025.)
    ratios.append(scaled_check(matrix,a[prefix+'A_complex'],scale,1e-10))
assert sum(a[f'order_{order}_potential'].nbytes for order in (12,16,20))==66355200==r['retained_field_bytes']
payload=path.with_suffix('.payload.zip')
with payload.open('rb') as file:assert stream_hash(file)==r['payload_package']['sha256']
with ZipFile(payload) as z:
    assert z.testzip() is None
    with z.open('arrays.npz') as file:assert stream_hash(file)==r['arrays_sha256']
    from hashlib import sha256
    assert sha256(z.read('payload-manifest.json')).hexdigest()==r['payload_package']['snapshot_sha256']
with ZipFile(archive/'probe.zip') as z:spec=json.loads(z.read('external-inputs.json'))
for item in spec['external']:item['copy_to']='validation/'+stem+'.source/'+item['argument']+'.zip'
spec['study']['copy_to']='validation/'+stem+'.source/study.zip'
for item in spec['external']+[spec['study']]:assert digest(Path('artifacts')/item['copy_to'])==item['sha256']
restore='''from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import argparse,json,shutil
p=argparse.ArgumentParser()
for name in ('common','quadrature','historical'):p.add_argument('--'+name+'-bundle',type=Path,required=True)
args=p.parse_args();root=Path(__file__).resolve().parent;stem='finest-consumer-rehearsal-001'
report=json.loads((root/'validation'/(stem+'.json')).read_text());payload=root/'validation'/(stem+'.payload.zip')
def digest(file):
    h=sha256()
    with file.open('rb') as stream:
        while chunk:=stream.read(1048576):h.update(chunk)
    return h.hexdigest()
def target(entry):
    out=(root/entry).resolve();assert out.is_relative_to(root);out.parent.mkdir(parents=True,exist_ok=True);return out
assert digest(payload)==report['payload_package']['sha256']
with ZipFile(payload) as z:
    with z.open('arrays.npz') as source,target('validation/'+stem+'.npz').open('wb') as dest:shutil.copyfileobj(source,dest)
    for item in z.infolist():
        if item.filename.startswith('source/') and not item.is_dir():
            out=target('validation/'+stem+'.source/'+item.filename[len('source/'):])
            with z.open(item) as source,out.open('wb') as dest:shutil.copyfileobj(source,dest)
assert digest(root/'validation'/(stem+'.npz'))==report['arrays_sha256']
spec=json.loads((root/'external-inputs.json').read_text())
for item in spec['external']:
    source=getattr(args,item['argument']+'_bundle');assert digest(source)==item['sha256'];shutil.copyfile(source,target(item['copy_to']))
with ZipFile(args.historical_bundle) as z:parent=z.read(spec['study']['extract_entry'])
assert sha256(parent).hexdigest()==spec['study']['sha256'];target(spec['study']['copy_to']).write_bytes(parent)
print('Immutable resource NPZ/source graph and all exact input bundles restored. Synthetic fields remain resource-only.')
'''
junit=Path('artifacts/pytest-consumer-all-002.xml');suites=ET.parse(junit).findall('.//testsuite');checks={key:sum(int(x.attrib.get(key,0)) for x in suites) for key in ('tests','failures','errors','skipped')};assert checks==dict(tests=284,failures=0,errors=0,skipped=0)
bundle=Path('validation/evidence/finest-consumer-rehearsal-001.zip');assert not bundle.exists()
with ZipFile(bundle,'x',ZIP_DEFLATED) as z:
    z.write(path,'validation/'+stem+'.json');z.write(payload,'validation/'+stem+'.payload.zip',compress_type=ZIP_STORED)
    z.writestr('external-inputs.json',json.dumps(spec,indent=2)+'\n');z.writestr('restore_inputs.py',restore)
    z.writestr('README.txt','Resource-only synthetic data. After extraction run python restore_inputs.py --common-bundle PATH --quadrature-bundle PATH --historical-bundle PATH using tracked prior inputs. NPZ and actual source graph are restored from immutable payload.zip; no duplicate112MB NPZ is needed. All physical/reference flags remain false.\n')
    z.write(junit,'checks/'+junit.name);z.write(__file__,'pack_finest_consumer.py')
assert bundle.stat().st_size<100*1024**2
necessary=np.maximum((abs(ca['source_latest_increment'])+ca['latest_quadrature_charge']-1e-6*scale)/.001,0)
summary={key:r[key] for key in ('current_commit','complete','passed','mode','resource_only','synthetic_fields','rehearsal_passed','full_run_authorized','full_reference_qualified','source_discretization_qualified','native_evaluated_points','new_bem_solves','completed_stages','memory_records','latest_memory','retained_field_bytes','accounted_additional_disk_upper_bytes','payload_package','elapsed_seconds')}
summary.update(bundle_sha256=digest(bundle),external_inputs=spec,tests=checks,maximum_synthetic_load_reconstruction_ratio=max(ratios),
    necessary_not_sufficient_next_finest_abs_magnitudes=necessary.tolist(),current_864_source_A=ca['source_A'][-1].tolist(),
    qualification_strategy='Do not spend the long fourth-source field run seeking qualification of this rejected family; retained216-to864 increment needs implausibly large next finest coefficients. Preflight fixed-seed003 assets/quality and controlled output integration instead. Not a continuum bound or proven sliver causality.')
bundle.with_name('finest-consumer-rehearsal-001-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(bundle=str(bundle),bytes=bundle.stat().st_size,sha256=summary['bundle_sha256'],necessary_diagonals=necessary.diagonal().tolist()),indent=2))
