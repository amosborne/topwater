from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import argparse,json,shutil
p=argparse.ArgumentParser();p.add_argument('--quadrature-bundle',type=Path,required=True);p.add_argument('--historical-bundle',type=Path,required=True);args=p.parse_args()
root=Path(__file__).resolve().parent;spec=json.loads((root/'external-inputs.json').read_text())
def target(entry):
    out=(root/entry).resolve();assert out.is_relative_to(root);out.parent.mkdir(parents=True,exist_ok=True);return out
for item in spec['external']:
    payload=getattr(args,item['argument']+'_bundle');assert sha256(payload.read_bytes()).hexdigest()==item['sha256'];shutil.copyfile(payload,target(item['copy_to']))
with ZipFile(args.historical_bundle) as z:payload=z.read(spec['study']['extract_entry'])
assert sha256(payload).hexdigest()==spec['study']['sha256'];target(spec['study']['copy_to']).write_bytes(payload)
print('All three exact input bundles restored from SHA-pinned tracked evidence.')
