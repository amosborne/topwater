"""Separate known-incident and scattered angular representation diagnostics."""
import json
from pathlib import Path
import shutil
import numpy as np
from tests.validation.common import prepare,save,read_owned,digest,current_sources
from tests.validation.periodic_grid import mean_angles,periodic_interpolate
from tests.validation.periodic_fields import boundary_limits

controls=Path('validation/periodic-grid-controls.json')
source=Path('artifacts/validation/periodic-fields-001.json')
output=Path('artifacts/validation/field-sampling-001.json')
report=prepare(output,controls,'periodic-field-sampling-diagnostic')
relative=Path(__file__).resolve().relative_to(Path.cwd())
target=output.with_suffix('.source')/relative;target.parent.mkdir(parents=True,exist_ok=True)
shutil.copyfile(relative,target);report['producer_sha256'][relative.as_posix()]=digest(relative)
r,a=read_owned(source,digest(controls),'periodic-field-map-candidate')
current_sources(r,tuple(r['producer_sha256']))
report.update(input_manifest_sha256=digest(source),input_arrays_sha256=digest(source.with_suffix('.npz')),
    scope=__doc__,full_reference_qualified=False,nonlinear_restart_ready=False)
save(output,report,{})
angles=a['angles_rad'];n=len(angles);nr=a['potential_phasors'].shape[2]
incident=a['incident_potential_samples']
inc=np.concatenate((boundary_limits(incident[:,:4*n].reshape(3,4,n))[:,-1:,:],
                    incident[:,4*n:].reshape(3,nr-1,n)),axis=1)
with np.load('artifacts/validation/frozen-fixed-001.npz') as frozen:
    wet=frozen['wetted_triangles'].copy()
origin=a['world_cg'][:2];out={};diagnostics={}
for kind,phi in (('total',a['potential_phasors'][-1]),('incident',inc),
                  ('scattered',a['potential_phasors'][-1]-inc)):
    diagnostics[kind]={}
    for name,field in (('potential',phi),('elevation',1j*a['angular_frequencies_rad_s'][:,None,None]*phi/r['gravity_m_s2'])):
        interpolated=[]
        for divisions in (32,64):
            coarse=mean_angles(wet,origin,divisions)
            index=[np.argmin(abs(angles-x)) for x in coarse]
            interpolated.append(periodic_interpolate(coarse,field[:,:,index],angles))
        previous=abs(interpolated[1]-interpolated[0]);latest=abs(field-interpolated[1])
        prefix=kind+'_'+name+'_'
        out[prefix+'previous']=previous;out[prefix+'latest']=latest
        diagnostics[kind][name]=dict(
            previous_sum_component_max_per_row=previous.max(axis=2).sum(axis=0).tolist(),
            latest_sum_component_max_per_row=latest.max(axis=2).sum(axis=0).tolist(),
            envelope_sum_components_then_max_per_row=np.maximum(previous,latest).sum(axis=0).max(axis=1).tolist())
report.update(complete=True,passed=False,diagnostics=diagnostics,
    interpretation='Angular interpolation is grid/initial-state representation error, separate from Capytaine source-mesh uncertainty; no motion-error bound inferred')
save(output,report,out)
print(json.dumps(diagnostics,indent=2))
