from pathlib import Path
from hashlib import sha256
import json,shutil
root=Path(__file__).resolve().parent
s=json.loads((root/'shared-inputs.json').read_text());payload=root/s['payload_entry']
assert sha256(payload.read_bytes()).hexdigest()==s['sha256']
for entry in s['expected_entries']:
    target=(root/entry).resolve();assert target.is_relative_to(root)
    target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists():shutil.copyfile(payload,target)
    assert sha256(target.read_bytes()).hexdigest()==s['sha256']
print('All shared parent archives restored and verified.')
