from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,xml.etree.ElementTree as ET
import numpy as np
from topwater.rankine import TrianglePanels
from tests.validation.common import read_owned,digest,current_sources
from tests.validation.frozen_source_quadrature import pressure_matrix,telescoping
from tests.validation.paired_body import scaled_check

root=Path('artifacts/validation')
names=['frozen-source-gauss-continuation-001','frozen-gauss-continuation-attribution-001']
contract='validation/frozen-source-gauss-continuation-controls.json'
r,a=read_owned(root/(names[0]+'.json'),digest(contract),'frozen-source-pressure-quadrature')
d,b=read_owned(root/(names[1]+'.json'),digest(contract),'frozen-quadrature-attribution')
for report in (r,d):
    current_sources(report,tuple(report['producer_sha256']))
    assert report['complete'] and not report['passed'] and not report['full_reference_qualified']
assert r['completed_levels']==4 and r['new_bem_solves']==0 and r['elapsed_seconds']<=400
assert not r['source_discretization_qualified']
assert d['parent_manifest_sha256']==digest(root/(names[0]+'.json'))
assert d['parent_arrays_sha256']==digest(root/(names[0]+'.npz'))
scale=np.sqrt(a['dry_mass'].diagonal()[:,None]*a['dry_mass'].diagonal()[None,:])
p=TrianglePanels(a['source_triangles'],-1);ratios=[]
for level in range(4):
    prefix=f'level{level}_';owner=a[prefix+'owners']
    reconstructed=pressure_matrix(a[prefix+'points'],p.normals[owner],a[prefix+'weights'],a[prefix+'potential'],a['world_cg'],1025.)
    ratios.append(scaled_check(reconstructed,a[prefix+'A_complex'],scale,1e-10))
    telescoping(a['native_coarse_A'],a['native_finer_A'],reconstructed,scale,1e-10)
    for name in ('measured_total_increment','output_quadrature_change','unresolved_remainder'):
        np.testing.assert_array_equal(a[prefix+name],b[prefix+name])
        np.testing.assert_array_equal(abs(a[prefix+name]),b[prefix+name+'_absolute'])
external=dict(filename='frozen-source-gauss-001.zip',sha256=r['reused_bundle_sha256'],
    copy_to='validation/'+names[0]+'.source/reuse.zip',
    extract_entry='validation/frozen-source-gauss-001.source/parent.zip',
    parent_sha256=r['parent_bundle_sha256'],parent_targets=['validation/'+name+'.source/parent.zip' for name in names])
shared=dict(sha256=r['arrays_sha256'],payload_entry='validation/'+names[0]+'.npz',
    copy_to='validation/'+names[1]+'.source/quadrature.npz')
for name in names:assert digest(root/(name+'.source')/'parent.zip')==external['parent_sha256']
assert digest(root/(names[0]+'.source')/'reuse.zip')==external['sha256']
assert digest(root/(names[1]+'.source')/'quadrature.npz')==shared['sha256']
restore='''from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import argparse,json,shutil
p=argparse.ArgumentParser();p.add_argument('--reuse-bundle',type=Path,required=True);args=p.parse_args()
root=Path(__file__).resolve().parent
spec=json.loads((root/'shared-inputs.json').read_text());external=spec['external'];shared=spec['shared']
assert sha256(args.reuse_bundle.read_bytes()).hexdigest()==external['sha256']
def target(entry):
    out=(root/entry).resolve();assert out.is_relative_to(root);out.parent.mkdir(parents=True,exist_ok=True);return out
out=target(external['copy_to']);shutil.copyfile(args.reuse_bundle,out)
with ZipFile(args.reuse_bundle) as z:payload=z.read(external['extract_entry'])
assert sha256(payload).hexdigest()==external['parent_sha256']
for entry in external['parent_targets']:target(entry).write_bytes(payload)
payload=root/shared['payload_entry'];assert sha256(payload.read_bytes()).hexdigest()==shared['sha256']
shutil.copyfile(payload,target(shared['copy_to']))
print('External SHA-pinned historical bundle and all shared inputs restored.')
'''
junit=Path('artifacts/pytest-frozen-gauss-cont-all-001.xml');suites=ET.parse(junit).findall('.//testsuite')
checks={k:sum(int(x.attrib.get(k,0)) for x in suites) for k in ('tests','failures','errors','skipped')}
assert checks==dict(tests=273,failures=0,errors=0,skipped=0)
skip={external['copy_to'],shared['copy_to'],*external['parent_targets']}
bundle=Path('validation/evidence/frozen-source-gauss-continuation-001.zip');assert not bundle.exists()
with ZipFile(bundle,'x',ZIP_DEFLATED) as z:
    for name in names:
        for suffix in ('.json','.npz'):z.write(root/(name+suffix),'validation/'+name+suffix)
        for path in sorted((root/(name+'.source')).rglob('*')):
            if not path.is_file():continue
            entry='validation/'+name+'.source/'+path.relative_to(root/(name+'.source')).as_posix()
            if entry not in skip:z.write(path,entry)
    z.writestr('shared-inputs.json',json.dumps(dict(external=external,shared=shared),indent=2)+'\n')
    z.writestr('restore_shared_inputs.py',restore)
    z.writestr('README.txt','This evidence consists of this archive AND sibling frozen-source-gauss-001.zip (SHA in shared-inputs.json). After extraction run python restore_shared_inputs.py --reuse-bundle PATH_TO_SIBLING_ZIP. Historical producers remain separately identified; full qualification is false.\n')
    z.write(junit,'checks/'+junit.name);z.write(__file__,'pack_frozen_gauss_continuation.py')
summary={k:r[k] for k in ('current_commit','complete','passed','completed_levels','new_bem_solves','full_reference_qualified',
    'source_discretization_qualified','elapsed_seconds','levels','quadrature_stabilization','failed_entries','interpretation')}
summary.update(bundle_sha256=digest(bundle),shared_inputs=dict(external=external,shared=shared),tests=checks,
    maximum_archived_load_reconstruction_ratio=max(ratios),quadrature_diagonals=a['quadrature_A'].diagonal(axis1=1,axis2=2).tolist(),
    output_change_diagonal=d['output_change_diagonal'],unresolved_remainder_diagonal=d['remainder_diagonal'])
bundle.with_name('frozen-source-gauss-continuation-001-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(bundle=str(bundle),bytes=bundle.stat().st_size,sha256=summary['bundle_sha256'],tests=checks),indent=2))
