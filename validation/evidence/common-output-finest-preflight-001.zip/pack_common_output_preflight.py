from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,xml.etree.ElementTree as ET
import numpy as np
from tests.validation.common import read_owned,digest,current_sources
from tests.validation.common_output_preflight import work_model,resource_model

root=Path('artifacts/validation');stem='common-output-finest-preflight-001';path=root/(stem+'.json')
contract=Path('validation/common-output-preflight-controls.json');c=json.loads(contract.read_text())
r,a=read_owned(path,digest(contract),'common-output-finest-preflight');current_sources(r,tuple(r['producer_sha256']))
assert r['complete'] and not r['passed'] and not r['full_run_authorized']
assert r['native_evaluations']==r['new_bem_solves']==0 and not r['full_reference_qualified']
inputs={}
for name,kind,controls,filename in [('common','common-output-source-diagnostic','common-output-source-controls','common-output-sources-001'),
        ('study','paired-body-study','paired-body-controls','paired-body-study-002'),
        ('quadrature','frozen-source-pressure-quadrature','frozen-source-gauss-continuation-controls','frozen-source-gauss-continuation-001')]:
    report,arrays=read_owned(root/(filename+'.json'),digest('validation/'+controls+'.json'),kind)
    assert digest(root/(filename+'.json'))==r[name+'_manifest_sha256'];inputs[name]=(report,arrays,filename)
work=work_model(3456,[124416,221184,345600]);assert work==r['work']
resident=sum(x.nbytes for _,arrays,_ in inputs.values() for x in arrays.values())
largest=max((root/(filename+'.npz')).stat().st_size for _,_,filename in inputs.values())
archive=path.with_suffix('.source');bundle_bytes=sum((archive/(name+'.zip')).stat().st_size for name in ('common','study','quadrature','historical'))
producer_bytes=sum((archive/name).stat().st_size for name in r['producer_sha256'])
rates=[x['seconds']/(x['source_panels']*x['targets']) for x in r['timing_observations']]
model=resource_model(work,rates,resident,largest,bundle_bytes,producer_bytes,c);assert model==r['resource_model']
host=r['host_resources'];assert host['memory_available']==(host['available_physical_bytes']>=model['estimated_peak_bytes']*c['available_memory_margin'])
assert host['disk_available']==(host['available_disk_bytes']>=model['estimated_additional_disk_bytes']*c['available_disk_margin'])
assert r['resource_preflight_accepted']==(all(model['ceiling_checks'].values()) and host['memory_available'] and host['disk_available'])
prior=Path('validation/evidence/common-output-sources-001.zip')
with ZipFile(prior) as z:
    spec=json.loads(z.read('external-inputs.json'));restore=z.read('restore_inputs.py').decode()
external=spec['external']+[dict(argument='common',filename=prior.name,sha256=r['input_bundle_sha256']['common'],copy_to='validation/'+stem+'.source/common.zip')]
for item in external:
    item['copy_to']='validation/'+stem+'.source/'+item['argument']+'.zip'
    assert digest(archive/(item['argument']+'.zip'))==item['sha256']
study=spec['study'];study['copy_to']='validation/'+stem+'.source/study.zip'
assert digest(archive/'study.zip')==study['sha256']
restore=restore.replace("p=argparse.ArgumentParser();", "p=argparse.ArgumentParser();p.add_argument('--common-bundle',type=Path,required=True);")
junit=Path('artifacts/pytest-finest-preflight-all-001.xml');suites=ET.parse(junit).findall('.//testsuite')
checks={key:sum(int(x.attrib.get(key,0)) for x in suites) for key in ('tests','failures','errors','skipped')};assert checks==dict(tests=278,failures=0,errors=0,skipped=0)
bundle=Path('validation/evidence/common-output-finest-preflight-001.zip');assert not bundle.exists()
skip={item['copy_to'] for item in external}|{study['copy_to']}
with ZipFile(bundle,'x',ZIP_DEFLATED) as z:
    for suffix in ('.json','.npz'):z.write(path.with_suffix(suffix),'validation/'+stem+suffix)
    for file in sorted(archive.rglob('*')):
        if not file.is_file():continue
        entry='validation/'+stem+'.source/'+file.relative_to(archive).as_posix()
        if entry not in skip:z.write(file,entry)
    z.writestr('external-inputs.json',json.dumps(dict(external=external,study=study),indent=2)+'\n');z.writestr('restore_inputs.py',restore)
    z.writestr('README.txt','Required inputs: common-output-sources-001.zip, frozen-source-gauss-continuation-001.zip and frozen-source-gauss-001.zip. After extraction run python restore_inputs.py --common-bundle PATH --quadrature-bundle PATH --historical-bundle PATH. Accepted preflight permits only a separately bounded cost screen; full-run and physical qualification remain false.\n')
    z.write(junit,'checks/'+junit.name);z.write(__file__,'pack_common_output_preflight.py')
summary={key:r[key] for key in ('current_commit','complete','passed','native_evaluations','new_bem_solves','full_reference_qualified','source_discretization_qualified','resource_preflight_accepted','full_run_authorized','work','timing_observations','resource_model','host_resources','decision','elapsed_seconds','inspected_dependency_sha256')}
summary.update(bundle_sha256=digest(bundle),external_inputs=external,study_binding=study,tests=checks,
    reconstructed_model_inputs=dict(resident_array_bytes=resident,largest_payload_bytes=largest,input_bundle_bytes=bundle_bytes,producer_bytes=producer_bytes))
bundle.with_name('common-output-finest-preflight-001-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(bundle=str(bundle),bytes=bundle.stat().st_size,sha256=summary['bundle_sha256'],models_reconstructed=True),indent=2))
