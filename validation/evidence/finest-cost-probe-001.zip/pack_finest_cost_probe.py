from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,xml.etree.ElementTree as ET
import numpy as np
from topwater.rankine import TrianglePanels
from tests.validation.common import read_owned,digest,current_sources
from tests.validation.finest_cost_probe import owned_zip,sample_starts,projection
from tests.validation.frozen_source_quadrature import pressure_matrix,owned_points
from tests.validation.reference_mesh import facets
from tests.validation.paired_body import scaled_check

root=Path('artifacts/validation');stem='finest-cost-probe-001';path=root/(stem+'.json');archive=path.with_suffix('.source')
r,a=read_owned(path,digest('validation/finest-cost-probe-controls.json'),'finest-source-cost-probe');current_sources(r,tuple(r['producer_sha256']))
assert r['complete'] and not r['passed'] and r['probe_feasible'] and not r['full_run_authorized'] and not r['full_reference_qualified']
assert r['new_bem_solves']==0 and r['elapsed_seconds']<=60 and r['completed_orders']==3
common,data=owned_zip(archive/'common.zip','common-output-sources-001','common-output-source-diagnostic',digest('validation/common-output-source-controls.json'))
study,source=owned_zip(archive/'study.zip','paired-body-study-002','paired-body-study',digest('validation/paired-body-controls.json'))
np.testing.assert_array_equal(a['source_triangles'],source['triangles_3']);np.testing.assert_array_equal(a['normalized_sources'],source['capytaine_sources_3'])
scale=np.sqrt(a['dry_mass'].diagonal()[:,None]*a['dry_mass'].diagonal()[None,:]);panels=TrianglePanels(a['source_triangles'],-1)
A=pressure_matrix(a['native_points'],panels.normals,panels.areas,a['native_potential'],a['world_cg'],1025.)
load_ratio=scaled_check(A,a['native_A_complex'],scale,1e-10)
scaled_check(a['native_potential'],source['capytaine_aux_3'],1.,1e-10);scaled_check(A,source['capytaine_Ainf'][3],scale,1e-10)
normals=np.array([f['normal'] for f in facets(source['parent_body_triangles'])]);times=[];total=3456
for row in r['orders']:
    order=row['order'];key=f'target_{order}_';prefix=f'order_{order}_';n=len(data[key+'points'])
    labels=np.linalg.norm(data[key+'normal'][:,None,:]+normals[None,:,:],axis=2).argmin(axis=1)
    starts=sample_starts(labels);assert starts==row['starts']
    indices=np.array([np.arange(s,s+100) for s in starts]);np.testing.assert_array_equal(indices,a[prefix+'indices'])
    for name in ('points','owners','weights'):np.testing.assert_array_equal(a[prefix+name],data[key+name][indices.ravel()])
    np.testing.assert_array_equal(a[prefix+'facet_ids'],labels[indices.ravel()])
    for base in (0,n//2):
        selected=np.concatenate([np.arange(s,s+100) for s in starts if base<=s<base+n//2])
        assert set(labels[selected])==set(labels[base:base+n//2])
    assert owned_points(a[prefix+'points'],a[prefix+'owners'],data['target_triangles'],1e-10)==row['ownership']
    assert np.isfinite(a[prefix+'potential']).all() and a[prefix+'potential'].shape==(len(starts)*100,6)
    times+=row['block_seconds'];total+=len(starts)*100
assert total==r['native_evaluated_points']
estimate=projection(times,3456,2388787200,r['native_seconds'],1.25,max(60.,r['preparation_seconds']));assert estimate==r['projection']
assert max(r['latest_memory']['peak_working_set_bytes'],r['latest_memory']['peak_committed_bytes'])<=2*1024**3
with ZipFile(archive/'preflight.zip') as z:
    spec=json.loads(z.read('external-inputs.json'));restore=z.read('restore_inputs.py').decode()
for item in spec['external']:item['copy_to']='validation/'+stem+'.source/'+item['argument']+'.zip'
spec['study']['copy_to']='validation/'+stem+'.source/study.zip'
for item in spec['external']+[spec['study']]:assert digest(Path('artifacts')/item['copy_to'])==item['sha256']
junit=Path('artifacts/pytest-finest-probe-all-001.xml');suites=ET.parse(junit).findall('.//testsuite')
checks={key:sum(int(x.attrib.get(key,0)) for x in suites) for key in ('tests','failures','errors','skipped')};assert checks==dict(tests=280,failures=0,errors=0,skipped=0)
bundle=Path('validation/evidence/finest-cost-probe-001.zip');assert not bundle.exists()
skip={item['copy_to'] for item in spec['external']}|{spec['study']['copy_to']}
with ZipFile(bundle,'x',ZIP_DEFLATED) as z:
    for suffix in ('.json','.npz'):z.write(path.with_suffix(suffix),'validation/'+stem+suffix)
    for file in sorted(archive.rglob('*')):
        if not file.is_file():continue
        entry='validation/'+stem+'.source/'+file.relative_to(archive).as_posix()
        if entry not in skip:z.write(file,entry)
    z.writestr('external-inputs.json',json.dumps(spec,indent=2)+'\n');z.writestr('restore_inputs.py',restore)
    z.writestr('README.txt','After extraction run python restore_inputs.py --common-bundle PATH --quadrature-bundle PATH --historical-bundle PATH using tracked prior archives. Exact preflight.zip is embedded. Timing/memory probe only; full run and source/reference qualification remain false.\n')
    z.write(junit,'checks/'+junit.name);z.write(__file__,'pack_finest_cost_probe.py')
summary={key:r[key] for key in ('current_commit','complete','passed','probe_feasible','full_run_authorized','full_reference_qualified','source_discretization_qualified',
    'native_evaluated_points','new_bem_solves','native_seconds','preparation_seconds','native_potential_ratio','native_load_ratio','orders','projection','memory_records','latest_memory','elapsed_seconds','inspected_dependency_sha256','native_binary_sha256')}
summary.update(bundle_sha256=digest(bundle),external_inputs=spec,tests=checks,native_load_reconstruction_ratio=load_ratio,
    measured_peak_plus_future_fields_load_and_64MiB_reserve=r['latest_memory']['peak_committed_bytes']+66686976+49766400+64*1024**2)
bundle.with_name('finest-cost-probe-001-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(bundle=str(bundle),bytes=bundle.stat().st_size,sha256=summary['bundle_sha256']),indent=2))
