from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED, ZIP_STORED
import json, subprocess, sys, xml.etree.ElementTree as ET
from tests.validation.common import digest, read_owned, current_sources
from tests.validation.finest_consumer import stream_hash

stem='fixed-source-export-002'; root=Path('artifacts/validation'); path=root/(stem+'.json')
r,a=read_owned(path,digest('validation/fixed-source-export-controls.json'),'fixed-seed-infinite-source-export')
current_sources(r,tuple(r['producer_sha256']))
assert r['complete'] and r['source_export_complete'] and not r['passed']
assert r['completed_capytaine_calls']==18 and r['total_source_cases_represented']==24
assert r['common_grid_evaluations']==0 and r['covered_source_levels']==[1,2,3,4]
assert not any(r[k] for k in ('full_reference_qualified','source_discretization_qualified','full_run_authorized'))
payload=path.with_suffix('.payload.zip')
assert digest(payload)==r['payload_package']['sha256']
with ZipFile(payload) as z:
    assert z.testzip() is None
    with z.open('arrays.npz') as f: assert stream_hash(f)==r['arrays_sha256']
with ZipFile(root/(stem+'.source')/'pilot.zip') as z: external=json.loads(z.read('external-inputs.json'))
for item in external:
    item['copy_to']=['validation/'+stem+'.source/'+item['argument']+'.zip']
    assert digest(root/(stem+'.source')/(item['argument']+'.zip'))==item['sha256']
# Reuse the already audited immutable-payload restoration helper, with exact stem substitution.
with ZipFile('validation/evidence/fixed-infinity-pilot-001.zip') as z:
    restore=z.read('restore_inputs.py').decode().replace('fixed-infinity-pilot-001',stem)
junit=Path('artifacts/pytest-source-export-all-003.xml')
suites=ET.parse(junit).findall('.//testsuite')
checks={k:sum(int(x.attrib.get(k,0)) for x in suites) for k in ('tests','failures','errors','skipped')}
assert checks==dict(tests=292,failures=0,errors=0,skipped=0)
bundle=Path('validation/evidence/fixed-source-export-002.zip'); assert not bundle.exists()
with ZipFile(bundle,'x',ZIP_DEFLATED) as z:
    z.write(path,'validation/'+stem+'.json')
    z.write(payload,'validation/'+stem+'.payload.zip',compress_type=ZIP_STORED)
    failed='fixed-source-export-001'
    for suffix in ('.json','.npz'):z.write(root/(failed+suffix),'validation/'+failed+suffix)
    for p in sorted((root/(failed+'.source')).rglob('*')):
        if p.is_file():z.write(p,p.relative_to(root.parent).as_posix())
    z.writestr('restore_inputs.py',restore)
    z.writestr('external-inputs.json',json.dumps(external,indent=2)+'\n')
    z.write(junit,'checks/'+junit.name);z.write(__file__,'pack_fixed_source_export.py')
    z.writestr('README.txt','Source export only: 18 fresh + 6 historical cases. No output-grid or reference qualification. Failed001 reader attempt preserved before native work. Restore with helper and exact frozen/raw/sources archives listed in external-inputs.json.\n')
summary={k:r[k] for k in ('current_commit','complete','passed','source_export_complete','completed_capytaine_calls','total_source_cases_represented','covered_source_levels','common_grid_evaluations','levels','reused_coarsest','allocation_model','latest_memory','accounted_disk_upper_bytes','elapsed_seconds','payload_package')}
summary.update(bundle_sha256=digest(bundle),tests=checks,external_inputs=external,independent_audit='Provenance, coarsest reuse, all four native load matrices, operator traces/residuals, cache, allocation, payload and resource checks passed; source/full qualification remains false.')
bundle.with_name('fixed-source-export-002-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
dest=Path('artifacts/fixed-source-export-bundle-audit-001').resolve();dest.mkdir(exist_ok=False)
with ZipFile(bundle) as z:
    assert z.testzip() is None
    assert all((dest/x.filename).resolve().is_relative_to(dest) for x in z.infolist())
    z.extractall(dest)
subprocess.run([sys.executable,str(dest/'restore_inputs.py'),
 '--frozen-bundle',str(Path('validation/evidence/frozen-fixed-001.zip').resolve()),
 '--raw-bundle',str(Path('validation/evidence/reference-study-003.zip').resolve()),
 '--sources-bundle',str(Path('validation/evidence/periodic-sources-003.zip').resolve())],check=True)
restored,arrays=read_owned(dest/'validation'/(stem+'.json'),r['contract_sha256'],r['kind'])
assert restored==r and arrays.keys()==a.keys()
for name,sha in r['producer_sha256'].items():assert digest(dest/'validation'/(stem+'.source')/name)==sha
for item in external:
    for entry in item['copy_to']:assert digest(dest/entry)==item['sha256']
failed=json.loads((dest/'validation/fixed-source-export-001.json').read_text())
assert not failed['complete'] and digest(dest/'validation/fixed-source-export-001.npz')==failed['arrays_sha256']
for name,sha in failed['producer_sha256'].items():assert digest(dest/'validation/fixed-source-export-001.source'/name)==sha
print(json.dumps(dict(bundle=str(bundle),bytes=bundle.stat().st_size,sha256=digest(bundle),restoration='verified',tests=checks),indent=2))
