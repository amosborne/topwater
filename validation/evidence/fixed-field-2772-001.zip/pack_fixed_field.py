from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED,ZIP_STORED
import json,subprocess,sys,xml.etree.ElementTree as ET
import numpy as np
from tests.validation.common import read_owned,digest,current_sources,mesh_quality
from tests.validation.finest_consumer import stream_hash
from tests.validation.frozen_source_quadrature import pressure_matrix
from tests.validation.fixed_field import source_interval
from tests.validation.paired_body import scaled_check

stem='fixed-field-2772-001';root=Path('artifacts/validation');path=root/(stem+'.json')
r,a=read_owned(path,digest('validation/fixed-field-2772-controls.json'),'fixed-seed-cold-field')
current_sources(r,tuple(r['producer_sha256']))
assert r['complete'] and not r['passed'] and r['native_calibration_passed'] and r['completed_capytaine_calls']==0 and r['completed_orders']==3
assert not any(r[k] for k in ('synthetic_fields','resource_only','source_discretization_qualified','full_reference_qualified','full_run_authorized'))
assert r['elapsed_seconds']<=900 and r['accounted_disk_upper_bytes']<=2*1024**3
assert max(r['latest_memory'][k] for k in ('peak_working_set_bytes','peak_committed_bytes'))<=2*1024**3
scale=np.sqrt(a['dry_mass'].diagonal()[:,None]*a['dry_mass'].diagonal()[None,:])
native=pressure_matrix(a['native_points'],a['native_normal'],a['native_weights'],a['native_potential'],a['world_cg'],1025.)
ratios=[scaled_check(native,a['native_A_complex'],scale,1e-10),scaled_check(native,a['exported_native_Ainf'],scale,1e-10)]
reconstructed=[]
for order in (12,16,20):
    key=f'target_{order}_';A=pressure_matrix(a[key+'points'],a[key+'normal'],a[key+'weights'],a[f'order_{order}_potential'],a['world_cg'],1025.)
    ratios.append(scaled_check(A,a[f'order_{order}_A_complex'],scale,1e-10))
    scaled_check(A.imag,np.zeros_like(A.real),scale,1e-10);reconstructed.append(A.real)
np.testing.assert_array_equal(np.stack(reconstructed),a['quadrature_A'])
U,gate=mesh_quality(a['quadrature_A']/scale,dict(reference_mesh_relative=.001,reference_mesh_absolute_normalized=1e-6))
assert gate==r['quadrature_stabilization'] and gate['passed']==r['integration_passed']
np.testing.assert_array_equal(U*scale,a['quadrature_uncertainty'])
previous=abs(a['quadrature_A'][1]-a['quadrature_A'][0])/scale;latest=abs(a['quadrature_A'][2]-a['quadrature_A'][1])/scale;allow=1e-6+.001*abs(a['quadrature_A'][2]/scale)
for k,v in dict(previous_ratio=previous/allow,latest_ratio=latest/allow,previous_failed=previous>allow,latest_failed=latest>allow,trend_failed=latest>previous+1e-6).items():np.testing.assert_array_equal(v,a[k])
for k,v in source_interval(a['coarse_quadrature_A'][-1],a['quadrature_A'][-1],a['coarse_quadrature_uncertainty'],a['quadrature_uncertainty'],scale).items():np.testing.assert_array_equal(v,a[k])
assert r['source_interval_diagnostic']==dict(intervals=1,qualified=False,all_entries_within_allowance=bool(not a['source_interval_failed'].any()),maximum_ratio=float(a['source_interval_ratio'].max()))
payload=path.with_suffix('.payload.zip');assert digest(payload)==r['payload_package']['sha256']
with ZipFile(payload) as z:
    assert z.testzip() is None
    with z.open('arrays.npz') as f:assert stream_hash(f)==r['arrays_sha256']
with ZipFile(root/(stem+'.source')/'source-export.zip') as z:external=json.loads(z.read('external-inputs.json'))
for item in external:
    item['copy_to']=['validation/'+stem+'.source/'+item['argument']+'.zip']
    assert digest(root/(stem+'.source')/(item['argument']+'.zip'))==item['sha256']
with ZipFile('validation/evidence/fixed-infinity-pilot-001.zip') as z:
    restore=z.read('restore_inputs.py').decode().replace('fixed-infinity-pilot-001',stem).replace('Actual infinite-source pilot NPZ/source/payload and all exact inputs restored. One-mesh scope retained.','Actual cold2772 fields, source graph and exact external inputs restored. Source/full qualification remains false.')
junit=Path('artifacts/pytest-field-2772-all-001.xml');suites=ET.parse(junit).findall('.//testsuite')
checks={k:sum(int(x.attrib.get(k,0)) for x in suites) for k in ('tests','failures','errors','skipped')}
assert checks==dict(tests=294,failures=0,errors=0,skipped=0)
bundle=Path('validation/evidence/'+stem+'.zip');assert not bundle.exists()
with ZipFile(bundle,'x',ZIP_DEFLATED) as z:
    z.write(path,'validation/'+stem+'.json');z.write(payload,'validation/'+stem+'.payload.zip',compress_type=ZIP_STORED)
    z.writestr('external-inputs.json',json.dumps(external,indent=2)+'\n');z.writestr('restore_inputs.py',restore)
    z.write(junit,'checks/'+junit.name);z.write(__file__,'pack_fixed_field.py')
    z.writestr('README.txt','Actual cold2772 common-grid fields and source-interval diagnostic. Zero BEM solves. Restore using helper with exact frozen/raw/sources archives in external-inputs.json. Neither single-interval agreement nor native reproduction establishes source/full convergence.\n')
summary={k:r[k] for k in ('current_commit','complete','passed','integration_passed','native_calibration_passed','completed_capytaine_calls','completed_orders','native_potential_ratio','native_load_ratio','native_seconds','orders','quadrature_stabilization','source_interval_diagnostic','latest_memory','accounted_disk_upper_bytes','elapsed_seconds','payload_package')}
summary.update(bundle_sha256=digest(bundle),external_inputs=external,tests=checks,maximum_load_reconstruction_ratio=max(ratios),
    source_discretization_qualified=False,full_reference_qualified=False,full_run_authorized=False,
    native_diagonal=a['exported_native_Ainf'].diagonal().tolist(),quadrature_diagonals=a['quadrature_A'].diagonal(axis1=1,axis2=2).tolist(),
    coarse_diagonal=a['coarse_quadrature_A'][-1].diagonal().tolist(),uncertainty=a['quadrature_uncertainty'].tolist(),
    failure_entries={k:np.argwhere(a[k]).tolist() for k in ('previous_failed','latest_failed','trend_failed','source_interval_failed')})
bundle.with_name(stem+'-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
dest=Path('artifacts/fixed-field-2772-bundle-audit-001').resolve();dest.mkdir(exist_ok=False)
with ZipFile(bundle) as z:
    assert z.testzip() is None and all((dest/x.filename).resolve().is_relative_to(dest) for x in z.infolist());z.extractall(dest)
subprocess.run([sys.executable,str(dest/'restore_inputs.py'),
 '--frozen-bundle',str(Path('validation/evidence/frozen-fixed-001.zip').resolve()),
 '--raw-bundle',str(Path('validation/evidence/reference-study-003.zip').resolve()),
 '--sources-bundle',str(Path('validation/evidence/periodic-sources-003.zip').resolve())],check=True)
restored,arrays=read_owned(dest/'validation'/(stem+'.json'),r['contract_sha256'],r['kind'])
assert restored==r and arrays.keys()==a.keys()
for k,v in a.items():np.testing.assert_array_equal(v,arrays[k])
for item in external:
    for entry in item['copy_to']:assert digest(dest/entry)==item['sha256']
assert digest(dest/'validation'/(stem+'.source')/'source-export.zip')==r['source_bundle_sha256']
assert digest(dest/'validation'/(stem+'.source')/'preflight.zip')==r['preflight_bundle_sha256']
print(json.dumps(dict(bundle=str(bundle),bytes=bundle.stat().st_size,sha256=digest(bundle),restoration='verified',tests=checks),indent=2))
