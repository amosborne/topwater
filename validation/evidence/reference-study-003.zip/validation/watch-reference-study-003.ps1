$ErrorActionPreference = 'Stop'
$referenceCandidates = Get-CimInstance Win32_Process -Filter "Name = 'python.exe'" | Where-Object { $_.CommandLine -like '*reference-study-003.json*' }
$referenceProcess = $referenceCandidates | ForEach-Object { Get-Process -Id $_.ProcessId } | Sort-Object WorkingSet64 -Descending | Select-Object -First 1
if ($null -eq $referenceProcess) { throw 'Exact reference-study-003 process is missing; do not restart it from this observer.' }
$referenceHandle = $referenceProcess.Handle
$referenceStarted = $referenceProcess.StartTime.ToUniversalTime().ToString('o')
$referencePeakWorking = [int64]0
$referencePeakCommit = [int64]0
$referenceSamples = [System.Collections.Generic.List[object]]::new()
$referenceOutput = Join-Path (Get-Location) 'artifacts/validation/reference-study-003-memory.json'
if (Test-Path -LiteralPath $referenceOutput) { throw 'Preserve previous observer report.' }
while (-not $referenceProcess.HasExited) {
    $referenceProcess.Refresh()
    $referencePeakWorking = [Math]::Max($referencePeakWorking, $referenceProcess.PeakWorkingSet64)
    $referencePeakCommit = [Math]::Max($referencePeakCommit, $referenceProcess.PeakPagedMemorySize64)
    $referenceSamples.Add([pscustomobject]@{UTC=(Get-Date).ToUniversalTime().ToString('o');WorkingSetBytes=$referenceProcess.WorkingSet64;CommittedBytes=$referenceProcess.PagedMemorySize64;PeakWorkingSetBytes=$referencePeakWorking;PeakCommittedBytes=$referencePeakCommit})
    [pscustomobject]@{ProcessId=$referenceProcess.Id;ProcessStartedUTC=$referenceStarted;Terminal=$false;PeakWorkingSetBytes=$referencePeakWorking;PeakCommittedBytes=$referencePeakCommit;Samples=$referenceSamples.ToArray()} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $referenceOutput -Encoding utf8
    Start-Sleep -Seconds 2
}
[pscustomobject]@{ProcessId=$referenceProcess.Id;ProcessStartedUTC=$referenceStarted;Terminal=$true;PeakWorkingSetBytes=$referencePeakWorking;PeakCommittedBytes=$referencePeakCommit;Samples=$referenceSamples.ToArray()} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $referenceOutput -Encoding utf8
Write-Output "Reference process terminal; resource observations retained: $referenceOutput"
