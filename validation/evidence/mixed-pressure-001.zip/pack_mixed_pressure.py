"""Preserve pressure probe/attribution with one SHA-bound shared parent payload."""
import json
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import numpy as np
from tests.validation.common import read_owned,digest,current_sources
from topwater import SimulationInputs

root=Path('artifacts/validation');probe='mixed-pressure-001';diagnostic='pressure-discrepancy-001'
r,a=read_owned(root/(probe+'.json'),digest('validation/mixed-pressure-controls.json'),'mixed-pressure-component')
d,b=read_owned(root/(diagnostic+'.json'),digest('validation/pressure-discrepancy-controls.json'),'pressure-discrepancy-diagnostic')
for report in (r,d):
    current_sources(report,tuple(report['producer_sha256']))
    assert report['complete'] and not report['passed'] and not report['full_reference_qualified']
for arrays in (a,b):
    assert all(np.isfinite(x).all() for x in arrays.values() if x.dtype.kind in 'fc')
assert not r['nonlinear_rhs_ready'] and not r['complete_runtime_speed_qualified'] and d['completed_capytaine_calls']==6
assert d['probe_manifest_sha256']==digest(root/(probe+'.json')) and d['probe_arrays_sha256']==digest(root/(probe+'.npz'))
assert max(abs(a['calm_acceleration_world']))<=1e-10
assert r['pressure']['balance_relative']<=1e-10
assert r['elapsed_seconds']<=180 and d['elapsed_seconds']<=60
np.testing.assert_array_equal(a['calm_added_mass'],b['closed_added_mass'])
np.testing.assert_array_equal(a['raw_reference_Ainf'],b['fine_reference_Ainf'])
archive=root/(probe+'.source');physical=(archive/'frozen-inputs.json').read_bytes()
with ZipFile(archive/'field-map.zip') as z:
    assert z.read('validation/periodic-fields-001.source/frozen-inputs.json')==physical
calm=SimulationInputs.from_json((archive/'calm-inputs.json').read_text())
assert len(calm.waves.amplitudes)==0 and not np.any(calm.initial_state.linear_velocity) and not np.any(calm.initial_state.angular_velocity)
sha=digest(archive/'field-map.zip')
assert sha==digest(root/(diagnostic+'.source')/'field-map.zip')==r['field_bundle_sha256']==d['field_bundle_sha256']
shared=dict(sha256=sha,payload_entry='validation/'+probe+'.source/field-map.zip',
    expected_entries=['validation/'+probe+'.source/field-map.zip','validation/'+diagnostic+'.source/field-map.zip'])
restore='''from pathlib import Path
from hashlib import sha256
import json,shutil
root=Path(__file__).resolve().parent
shared=json.loads((root/'shared-inputs.json').read_text())
payload=root/shared['payload_entry']
assert sha256(payload.read_bytes()).hexdigest()==shared['sha256']
for entry in shared['expected_entries']:
    target=(root/entry).resolve()
    assert target.is_relative_to(root)
    target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists():shutil.copyfile(payload,target)
    assert sha256(target.read_bytes()).hexdigest()==shared['sha256']
print('Shared input archives restored and SHA256 verified.')
'''
bundle=Path('validation/evidence/mixed-pressure-001.zip');assert not bundle.exists()
with ZipFile(bundle,'x',ZIP_DEFLATED) as z:
    for name in (probe,diagnostic):
        for suffix in ('.json','.npz'):z.write(root/(name+suffix),'validation/'+name+suffix)
        for p in sorted((root/(name+'.source')).rglob('*')):
            if not p.is_file():continue
            if name==diagnostic and p.name=='field-map.zip':continue
            z.write(p,'validation/'+name+'.source/'+p.relative_to(root/(name+'.source')).as_posix())
    z.writestr('shared-inputs.json',json.dumps(shared,indent=2)+'\n')
    z.writestr('restore_shared_inputs.py',restore)
    z.writestr('README.txt','Both source archives share one identical parent payload. After extraction run python restore_shared_inputs.py to restore both original input paths with SHA verification. This is an unqualified component/diagnostic bundle, not a fluid-body baseline.\n')
    for p in ('tests/test_fluid_boundary.py','tests/test_pressure.py','artifacts/pytest-pressure-all-001.xml'):
        z.write(p,'checks/'+Path(p).name)
    z.write(__file__,'pack_mixed_pressure.py')
summary=dict(probe_source_commit=r['current_commit'],diagnostic_source_commit=d['current_commit'],
    complete=True,passed=False,full_reference_qualified=False,nonlinear_rhs_ready=False,complete_runtime_speed_qualified=False,
    calm_geometry=r['calm_geometry'],mild_geometry=r['mild_geometry'],stages=r['stages'],
    pressure_component_projection_wall_seconds_per_simulated_second=r['pressure_component_projection_wall_seconds_per_simulated_second'],
    cost_scope=r['cost_scope'],maximum_calm_acceleration_SI=float(max(abs(a['calm_acceleration_world']))),
    balance_relative=r['pressure']['balance_relative'],physical_surface_proof=d['physical_surface_proof'],
    diagnostic_comparisons=d['diagnostic_comparisons'],
    added_mass_diagonals={name:b[key].diagonal().tolist() for name,key in
        [('closed','closed_added_mass'),('halfspace','halfspace_added_mass'),('same_body_capytaine','same_body_capytaine_Ainf')]},
    fine_reference_diagonal=b['fine_reference_Ainf'][-1].diagonal().tolist(),
    bundle_sha256=digest(bundle),shared_input_bindings=shared,
    evidence_limit='Combined chi reconstructs saved body load; six chi auxiliary traces were not saved, so rawA cannot be reconstructed from this artifact alone. Preserve those traces in next producer.',
    interpretation='Multiple unresolved coarse-body/formulation and explicit-surface/domain contributions; finest reference itself remains unqualified. No exact-error or motion/speed claim.',
    checks_sha256={p:digest(p) for p in ('tests/test_fluid_boundary.py','tests/test_pressure.py','artifacts/pytest-pressure-all-001.xml')})
bundle.with_name('mixed-pressure-001-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(bundle=str(bundle),bytes=bundle.stat().st_size,sha256=summary['bundle_sha256'],passed=False),indent=2))
