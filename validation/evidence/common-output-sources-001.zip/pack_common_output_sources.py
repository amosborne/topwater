from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,xml.etree.ElementTree as ET
import numpy as np
from tests.validation.common import read_owned,digest,current_sources,mesh_quality
from tests.validation.common_output_sources import source_quality
from tests.validation.frozen_source_quadrature import pressure_matrix
from tests.validation.paired_body import scaled_check

stem='common-output-sources-001';root=Path('artifacts/validation');path=root/(stem+'.json')
r,a=read_owned(path,digest('validation/common-output-source-controls.json'),'common-output-source-diagnostic')
q,qa=read_owned(root/'frozen-source-gauss-continuation-001.json',digest('validation/frozen-source-gauss-continuation-controls.json'),'frozen-source-pressure-quadrature')
current_sources(r,tuple(r['producer_sha256']))
assert r['complete'] and not r['passed'] and r['completed_sources']==3 and r['new_bem_solves']==0 and r['elapsed_seconds']<=360
assert not r['full_reference_qualified'] and not r['source_discretization_qualified'] and not r['required_four_level_coverage']
assert r['quadrature_manifest_sha256']==digest(root/'frozen-source-gauss-continuation-001.json')
assert r['quadrature_arrays_sha256']==digest(root/'frozen-source-gauss-continuation-001.npz')
scale=np.sqrt(a['dry_mass'].diagonal()[:,None]*a['dry_mass'].diagonal()[None,:]);ratios=[]
for level in range(3):
    matrices=[]
    for i,order in enumerate((12,16,20),1):
        target=f'target_{order}_';prefix=f'source_{level}_order_{order}_'
        phi=qa[f'level{i}_potential'] if level==2 else a[prefix+'potential']
        A=pressure_matrix(a[target+'points'],a[target+'normal'],a[target+'weights'],phi,a['world_cg'],1025.)
        ratios.append(scaled_check(A,a[prefix+'A_complex'],scale,1e-10));matrices.append(a[prefix+'A_complex'].real.copy())
    U,gate=mesh_quality(np.stack(matrices)/scale,dict(reference_mesh_relative=.001,reference_mesh_absolute_normalized=1e-6))
    assert gate==r['source_records'][level]['quadrature_stabilization']
    np.testing.assert_array_equal(U*scale,a[f'source_{level}_quadrature_uncertainty'])
diagnostics,gate=source_quality(a['source_A'],a['quadrature_uncertainty'],scale)
for key,value in diagnostics.items():np.testing.assert_array_equal(value,a[key])
gate['all_quadrature_passed']=all(x['quadrature_stabilization']['passed'] for x in r['source_records']);gate['passed'] &= gate['all_quadrature_passed']
assert gate==r['source_diagnostic']
external=[dict(argument='quadrature',filename='frozen-source-gauss-continuation-001.zip',sha256=r['input_bundle_sha256']['quadrature'],copy_to='validation/'+stem+'.source/quadrature.zip'),
    dict(argument='historical',filename='frozen-source-gauss-001.zip',sha256=r['input_bundle_sha256']['historical'],copy_to='validation/'+stem+'.source/historical.zip')]
study=dict(sha256=r['input_bundle_sha256']['study'],extract_entry='validation/frozen-source-gauss-001.source/parent.zip',copy_to='validation/'+stem+'.source/study.zip')
for item in external:assert digest(Path('artifacts')/item['copy_to'])==item['sha256']
assert digest(Path('artifacts')/study['copy_to'])==study['sha256']
restore='''from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import argparse,json,shutil
p=argparse.ArgumentParser();p.add_argument('--quadrature-bundle',type=Path,required=True);p.add_argument('--historical-bundle',type=Path,required=True);args=p.parse_args()
root=Path(__file__).resolve().parent;spec=json.loads((root/'external-inputs.json').read_text())
def target(entry):
    out=(root/entry).resolve();assert out.is_relative_to(root);out.parent.mkdir(parents=True,exist_ok=True);return out
for item in spec['external']:
    payload=getattr(args,item['argument']+'_bundle');assert sha256(payload.read_bytes()).hexdigest()==item['sha256'];shutil.copyfile(payload,target(item['copy_to']))
with ZipFile(args.historical_bundle) as z:payload=z.read(spec['study']['extract_entry'])
assert sha256(payload).hexdigest()==spec['study']['sha256'];target(spec['study']['copy_to']).write_bytes(payload)
print('All three exact input bundles restored from SHA-pinned tracked evidence.')
'''
junit=Path('artifacts/pytest-common-output-all-002.xml');suites=ET.parse(junit).findall('.//testsuite')
checks={k:sum(int(x.attrib.get(k,0)) for x in suites) for k in ('tests','failures','errors','skipped')};assert checks==dict(tests=276,failures=0,errors=0,skipped=0)
bundle=Path('validation/evidence/common-output-sources-001.zip');assert not bundle.exists()
skip={item['copy_to'] for item in external}|{study['copy_to']}
with ZipFile(bundle,'x',ZIP_DEFLATED) as z:
    for suffix in ('.json','.npz'):z.write(path.with_suffix(suffix),'validation/'+stem+suffix)
    for file in sorted(path.with_suffix('.source').rglob('*')):
        if not file.is_file():continue
        entry='validation/'+stem+'.source/'+file.relative_to(path.with_suffix('.source')).as_posix()
        if entry not in skip:z.write(file,entry)
    z.writestr('external-inputs.json',json.dumps(dict(external=external,study=study),indent=2)+'\n')
    z.writestr('restore_inputs.py',restore)
    z.writestr('README.txt','Required evidence: this archive, frozen-source-gauss-continuation-001.zip AND frozen-source-gauss-001.zip. After extraction run python restore_inputs.py --quadrature-bundle PATH --historical-bundle PATH. All inputs are SHA bound. Source/full reference remain unqualified.\n')
    z.write(junit,'checks/'+junit.name);z.write(__file__,'pack_common_output_sources.py')
assert bundle.stat().st_size<100*1024**2
summary={key:r[key] for key in ('current_commit','complete','passed','completed_sources','new_bem_solves','full_reference_qualified','source_discretization_qualified','required_four_level_coverage','source_records','source_diagnostic','elapsed_seconds','interpretation')}
summary.update(bundle_sha256=digest(bundle),external_inputs=external,study_binding=study,tests=checks,
    maximum_load_reconstruction_ratio=max(ratios),source_diagonals=a['source_A'].diagonal(axis1=1,axis2=2).tolist(),
    source_failure_entries={key:np.argwhere(a[key]).tolist() for key in ('source_previous_ratio_failed','source_latest_ratio_failed','source_trend_failed')})
bundle.with_name('common-output-sources-001-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(bundle=str(bundle),bytes=bundle.stat().st_size,sha256=summary['bundle_sha256']),indent=2))
