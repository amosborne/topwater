from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,xml.etree.ElementTree as ET
import numpy as np
from topwater.rankine import TrianglePanels
from tests.validation.common import read_owned,digest,current_sources
from tests.validation.frozen_source_quadrature import pressure_matrix,telescoping
from tests.validation.paired_body import scaled_check

root=Path('artifacts/validation');names=['frozen-source-gauss-001','frozen-gauss-attribution-001']
contract='validation/frozen-source-gauss-controls.json'
r,a=read_owned(root/(names[0]+'.json'),digest(contract),'frozen-source-pressure-quadrature')
d,b=read_owned(root/(names[1]+'.json'),digest(contract),'frozen-quadrature-attribution')
for report in (r,d):
    current_sources(report,tuple(report['producer_sha256']))
    assert report['complete'] and not report['passed'] and not report['full_reference_qualified']
assert r['completed_levels']==4 and r['new_bem_solves']==0 and r['elapsed_seconds']<=600
assert not r['quadrature_stabilization']['passed'] and not r['source_discretization_qualified']
assert d['parent_manifest_sha256']==digest(root/(names[0]+'.json'))
assert d['parent_arrays_sha256']==digest(root/(names[0]+'.npz'))
scale=np.sqrt(a['dry_mass'].diagonal()[:,None]*a['dry_mass'].diagonal()[None,:]);p=TrianglePanels(a['source_triangles'],-1)
ratios=[]
for level in range(4):
    prefix=f'level{level}_';owner=a[prefix+'owners']
    reconstructed=pressure_matrix(a[prefix+'points'],p.normals[owner],a[prefix+'weights'],a[prefix+'potential'],a['world_cg'],1025.)
    ratios.append(scaled_check(reconstructed,a[prefix+'A_complex'],scale,1e-10))
    telescoping(a['native_coarse_A'],a['native_finer_A'],reconstructed,scale,1e-10)
    for name in ('measured_total_increment','output_quadrature_change','unresolved_remainder'):
        np.testing.assert_array_equal(a[prefix+name],b[prefix+name])
        np.testing.assert_array_equal(abs(a[prefix+name]),b[prefix+name+'_absolute'])
shared=[dict(sha256=r['parent_bundle_sha256'],payload_entry='validation/'+names[0]+'.source/parent.zip',
    expected_entries=['validation/'+name+'.source/parent.zip' for name in names]),
    dict(sha256=r['arrays_sha256'],payload_entry='validation/'+names[0]+'.npz',
        expected_entries=['validation/'+names[0]+'.npz','validation/'+names[1]+'.source/quadrature.npz'])]
for entry in shared:
    for logical in entry['expected_entries']:
        assert digest(Path('artifacts')/logical)==entry['sha256']
restore='''from pathlib import Path
from hashlib import sha256
import json,shutil
root=Path(__file__).resolve().parent
for s in json.loads((root/'shared-inputs.json').read_text()):
    payload=root/s['payload_entry'];assert sha256(payload.read_bytes()).hexdigest()==s['sha256']
    for entry in s['expected_entries']:
        target=(root/entry).resolve();assert target.is_relative_to(root)
        target.parent.mkdir(parents=True,exist_ok=True)
        if not target.exists():shutil.copyfile(payload,target)
        assert sha256(target.read_bytes()).hexdigest()==s['sha256']
print('Shared quadrature inputs restored and SHA256 verified.')
'''
junit=Path('artifacts/pytest-frozen-gauss-all-001.xml');suites=ET.parse(junit).findall('.//testsuite')
checks={k:sum(int(x.attrib.get(k,0)) for x in suites) for k in ('tests','failures','errors','skipped')}
assert checks==dict(tests=272,failures=0,errors=0,skipped=0)
skip={logical for s in shared for logical in s['expected_entries'] if logical!=s['payload_entry']}
bundle=Path('validation/evidence/frozen-source-gauss-001.zip');assert not bundle.exists()
with ZipFile(bundle,'x',ZIP_DEFLATED) as z:
    for name in names:
        for suffix in ('.json','.npz'):z.write(root/(name+suffix),'validation/'+name+suffix)
        for path in sorted((root/(name+'.source')).rglob('*')):
            if not path.is_file():continue
            target='validation/'+name+'.source/'+path.relative_to(root/(name+'.source')).as_posix()
            if target not in skip:z.write(path,target)
    z.writestr('shared-inputs.json',json.dumps(shared,indent=2)+'\n');z.writestr('restore_shared_inputs.py',restore)
    z.writestr('README.txt','After extraction run python restore_shared_inputs.py to restore exact shared input paths with SHA verification. All pressure stabilization/reference qualification remains false.\n')
    z.write(junit,'checks/'+junit.name);z.write(__file__,'pack_frozen_gauss.py')
summary={k:r[k] for k in ('current_commit','complete','passed','completed_levels','new_bem_solves','full_reference_qualified',
    'source_discretization_qualified','elapsed_seconds','levels','quadrature_stabilization','failed_entries','interpretation')}
summary.update(bundle_sha256=digest(bundle),shared_input_bindings=shared,tests=checks,
    maximum_archived_load_reconstruction_ratio=max(ratios),quadrature_diagonals=a['quadrature_A'].diagonal(axis1=1,axis2=2).tolist(),
    finer_native_diagonal=a['native_finer_A'].diagonal().tolist(),output_change_diagonal=d['output_change_diagonal'],
    unresolved_remainder_diagonal=d['remainder_diagonal'])
bundle.with_name('frozen-source-gauss-001-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(bundle=str(bundle),bytes=bundle.stat().st_size,sha256=summary['bundle_sha256'],tests=checks),indent=2))
