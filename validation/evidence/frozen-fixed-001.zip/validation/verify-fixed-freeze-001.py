"""Reproduce the frozen-mesh adoption proof; no hydrodynamic solve."""
import argparse
import json
from pathlib import Path
import numpy as np
from tests.validation.common import read_owned,digest,current_sources
from tests.validation.reference_mesh import verify_surface
from tests.capytaine_reference import body_from_triangles

parser=argparse.ArgumentParser(description=__doc__)
for name in ('frozen','preflight','physical-reference','output'):
    parser.add_argument('--'+name,type=Path,required=True)
args=parser.parse_args()
if args.output.exists():raise FileExistsError('proof output must be fresh')
def owned(path,kind):
    return read_owned(path,digest(path.with_suffix('.source')/'contract.json'),kind,passed=True)
r,z=owned(args.frozen,'freeze');p,m=owned(args.preflight,'transfinite-geometry-preflight')
original,o=owned(args.physical_reference,'freeze')
current_sources(r,tuple(r['producer_sha256']))
canonical=json.loads(args.frozen.with_suffix('.source').joinpath('contract.json').read_text())
assert digest('validation/canonical-boat.json')==r['contract_sha256']
previous=json.loads(args.preflight.with_suffix('.source').joinpath('canonical-contract.json').read_text())
unchanged={name:canonical[name]==previous[name] for name in canonical if name!='reference_numerics'}
resource_keys=('maximum_estimated_workspace_bytes','maximum_elapsed_seconds','cpu_threads',
    'capytaine_version','finite_green_settings','infinite_green_settings','richardson_extrapolation')
unchanged.update({'reference_numerics.'+key:canonical['reference_numerics'][key]==previous['reference_numerics'][key] for key in resource_keys})
assert all(unchanged.values())
physical=('wetted_triangles','world_cg','orientation','dry_mass','hydrostatic_stiffness','body_mass','hull_length','hull_beam')
equality={name:bool(z[name].dtype==o[name].dtype and np.array_equal(z[name],o[name])) for name in physical}
equality['input_json_bytes']=args.frozen.with_suffix('.source').joinpath('inputs.json').read_bytes()==args.physical_reference.with_suffix('.source').joinpath('inputs.json').read_bytes()
assert all(equality.values())
assert np.array_equal(z['reference_seed_triangles'],m['seed_triangles'])
rows=[]
for level,n in zip(canonical['reference_numerics']['body_subdivision_levels'],canonical['reference_numerics']['subdivisions'],strict=True):
    t=z[f'reference_triangles_{level}']
    assert np.array_equal(t,m[f'triangles_{n}'])
    proof=verify_surface(z['wetted_triangles'],t)
    body=body_from_triangles(t,z['world_cg'],float(z['body_mass']))
    radius=np.linalg.norm(t-t.mean(axis=1)[:,None],axis=2).max(axis=1)
    error=float(abs(body.mesh.faces_radiuses-radius).max())
    assert error<=1e-14
    rows.append(dict(level=level,subdivisions=n,panels=len(t),bitwise_candidate_equal=True,
        radius_error_m=error,geometry=proof))
result=dict(current_commit=r['current_commit'],frozen_manifest_sha256=digest(args.frozen),
    canonical_contract_sha256=r['contract_sha256'],geometry_candidate_manifest_sha256=digest(args.preflight),
    verifier_sha256=digest('artifacts/validation/verify-fixed-freeze-001.py'),
    physical_equality_checks=equality,unchanged_contract_sections=unchanged,
    seed_bitwise_candidate_equal=True,levels=rows,all_current_producers_match=True,
    qualification_status='unqualified; geometry/control proof only; no hydrodynamic calls')
with args.output.open('x',encoding='utf-8') as out:json.dump(result,out,indent=2);out.write('\n')
print(json.dumps(result,indent=2))
