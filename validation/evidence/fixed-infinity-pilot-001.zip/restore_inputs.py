from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import argparse,json,shutil
p=argparse.ArgumentParser()
for name in ('frozen','raw','sources'):p.add_argument('--'+name+'-bundle',type=Path,required=True)
args=p.parse_args();root=Path(__file__).resolve().parent;stem='fixed-infinity-pilot-001'
r=json.loads((root/'validation'/(stem+'.json')).read_text());payload=root/'validation'/(stem+'.payload.zip')
def digest(file):
    h=sha256()
    with file.open('rb') as stream:
        while chunk:=stream.read(1048576):h.update(chunk)
    return h.hexdigest()
def target(entry):
    out=(root/entry).resolve();assert out.is_relative_to(root);out.parent.mkdir(parents=True,exist_ok=True);return out
assert digest(payload)==r['payload_package']['sha256']
with ZipFile(payload) as z:
    with z.open('arrays.npz') as source,target('validation/'+stem+'.npz').open('wb') as dest:shutil.copyfileobj(source,dest)
    for item in z.infolist():
        if item.filename.startswith('source/') and not item.is_dir():
            out=target('validation/'+stem+'.source/'+item.filename[len('source/'):])
            with z.open(item) as source,out.open('wb') as dest:shutil.copyfileobj(source,dest)
assert digest(root/'validation'/(stem+'.npz'))==r['arrays_sha256']
for item in json.loads((root/'external-inputs.json').read_text()):
    source=getattr(args,item['argument']+'_bundle');assert digest(source)==item['sha256']
    for entry in item['copy_to']:shutil.copyfile(source,target(entry))
print('Actual infinite-source pilot NPZ/source/payload and all exact inputs restored. One-mesh scope retained.')
