from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import argparse,json,shutil
p=argparse.ArgumentParser()
for name in ('common','quadrature','historical'):p.add_argument('--'+name+'-bundle',type=Path,required=True)
args=p.parse_args();root=Path(__file__).resolve().parent;stem='finest-consumer-rehearsal-001'
report=json.loads((root/'validation'/(stem+'.json')).read_text());payload=root/'validation'/(stem+'.payload.zip')
def digest(file):
    h=sha256()
    with file.open('rb') as stream:
        while chunk:=stream.read(1048576):h.update(chunk)
    return h.hexdigest()
def target(entry):
    out=(root/entry).resolve();assert out.is_relative_to(root);out.parent.mkdir(parents=True,exist_ok=True);return out
assert digest(payload)==report['payload_package']['sha256']
with ZipFile(payload) as z:
    with z.open('arrays.npz') as source,target('validation/'+stem+'.npz').open('wb') as dest:shutil.copyfileobj(source,dest)
    for item in z.infolist():
        if item.filename.startswith('source/') and not item.is_dir():
            out=target('validation/'+stem+'.source/'+item.filename[len('source/'):])
            with z.open(item) as source,out.open('wb') as dest:shutil.copyfileobj(source,dest)
assert digest(root/'validation'/(stem+'.npz'))==report['arrays_sha256']
spec=json.loads((root/'external-inputs.json').read_text())
for item in spec['external']:
    source=getattr(args,item['argument']+'_bundle');assert digest(source)==item['sha256'];shutil.copyfile(source,target(item['copy_to']))
with ZipFile(args.historical_bundle) as z:parent=z.read(spec['study']['extract_entry'])
assert sha256(parent).hexdigest()==spec['study']['sha256'];target(spec['study']['copy_to']).write_bytes(parent)
print('Immutable resource NPZ/source graph and all exact input bundles restored. Synthetic fields remain resource-only.')
