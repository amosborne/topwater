"""Archive complete paired evidence, preserving failed attempt and shared input."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json
import xml.etree.ElementTree as ET
import numpy as np
from topwater.rankine import TrianglePanels
from tests.validation.common import read_owned,digest,current_sources
from tests.validation.paired_body import scaled_check

root=Path('artifacts/validation');contract='validation/paired-body-controls.json'
cases=['paired-body-freeze-001','paired-body-study-001','paired-body-freeze-002','paired-body-study-002','paired-body-localization-001']
reports={};data={}
for name in cases:
    path=root/(name+'.json');r=json.loads(path.read_text());reports[name]=r
    assert r['contract_sha256']==digest(contract) and r['arrays_sha256']==digest(path.with_suffix('.npz'))
    for file,h in r['producer_sha256'].items():assert digest(path.with_suffix('.source')/file)==h
    with np.load(path.with_suffix('.npz')) as z:data[name]={k:z[k].copy() for k in z.files}
    assert all(np.isfinite(x).all() for x in data[name].values() if x.dtype.kind in 'fc')
for name in cases[2:]:current_sources(reports[name],tuple(reports[name]['producer_sha256']))
assert reports[cases[0]]['passed'] and reports[cases[2]]['passed']
assert not reports[cases[1]]['complete'] and reports[cases[1]]['completed_capytaine_calls']==0
assert reports[cases[1]]['error']['type']=='AttributeError'
for key in data[cases[0]]:np.testing.assert_array_equal(data[cases[0]][key],data[cases[2]][key])
r=reports[cases[3]];a=data[cases[3]];local=reports[cases[4]];la=data[cases[4]]
assert r['complete'] and not r['passed'] and r['completed_capytaine_calls']==24 and r['completed_topwater_levels']==4
assert not r['added_mass_reference_qualified'] and not r['full_reference_qualified']
assert not any(x['passed'] for x in r['gates'].values()) and r['elapsed_seconds']<=180
assert local['study_manifest_sha256']==digest(root/(cases[3]+'.json'))
assert local['study_arrays_sha256']==digest(root/(cases[3]+'.npz'))
scale=np.sqrt(a['dry_mass'].diagonal()[:,None]*a['dry_mass'].diagonal()[None,:]);ratios=[]
for level in range(4):
    p=TrianglePanels(a[f'triangles_{level}'],-1);N=np.c_[p.normals,np.cross(p.centroids-a['world_cg'],p.normals)]
    for method,field,matrix in [('topwater','topwater_aux','topwater_Ainf'),('capytaine','capytaine_aux','capytaine_Ainf')]:
        ratios.append(scaled_check(1025*N.T@(p.areas[:,None]*a[f'{field}_{level}']),a[matrix][level],scale,1e-10))
    scaled_check(a[f'capytaine_bc_{level}'],-N,1.,1e-10)
for entry in local['diagnostics']:
    prefix=entry['method']+'_'+str(entry['level'])+'_'
    expected=a[entry['method']+'_Ainf'][entry['level']]-a[entry['method']+'_Ainf'][entry['level']-1]
    scaled_check(la[prefix+'cell_matrix_increment'].sum(axis=0),expected,scale,1e-10)
parent_sha=reports[cases[2]]['parent_bundle_sha256']
payload='validation/'+cases[2]+'.source/parent.zip'
entries=['validation/'+name+'.source/parent.zip' for name in cases]
assert all(digest(root/(name+'.source')/'parent.zip')==parent_sha for name in cases)
shared=dict(sha256=parent_sha,payload_entry=payload,expected_entries=entries)
restore='''from pathlib import Path
from hashlib import sha256
import json,shutil
root=Path(__file__).resolve().parent
s=json.loads((root/'shared-inputs.json').read_text());payload=root/s['payload_entry']
assert sha256(payload.read_bytes()).hexdigest()==s['sha256']
for entry in s['expected_entries']:
    target=(root/entry).resolve();assert target.is_relative_to(root)
    target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists():shutil.copyfile(payload,target)
    assert sha256(target.read_bytes()).hexdigest()==s['sha256']
print('All shared parent archives restored and verified.')
'''
junit=Path('artifacts/pytest-paired-all-001.xml')
suites=ET.parse(junit).findall('.//testsuite')
checks={k:sum(int(x.attrib.get(k,0)) for x in suites) for k in ('tests','failures','errors','skipped')}
assert checks['tests']==261 and checks['failures']==checks['errors']==checks['skipped']==0
bundle=Path('validation/evidence/paired-body-001.zip');assert not bundle.exists()
with ZipFile(bundle,'x',ZIP_DEFLATED) as z:
    for name in cases:
        for suffix in ('.json','.npz'):z.write(root/(name+suffix),'validation/'+name+suffix)
        for p in sorted((root/(name+'.source')).rglob('*')):
            if not p.is_file():continue
            relative='validation/'+name+'.source/'+p.relative_to(root/(name+'.source')).as_posix()
            if p.name=='parent.zip' and relative!=payload:continue
            z.write(p,relative)
    z.writestr('shared-inputs.json',json.dumps(shared,indent=2)+'\n')
    z.writestr('restore_shared_inputs.py',restore)
    z.writestr('README.txt','After extraction run python restore_shared_inputs.py to restore the five identical parent input paths with SHA verification. Geometry scope passed; paired physical gates failed. Study001 is the preserved incomplete API attempt; study002 is complete. No full reference or TD baseline is qualified.\n')
    for p in (junit,Path('artifacts/paired-body-memory-prelaunch.json')):z.write(p,'checks/'+p.name)
    z.write(__file__,'pack_paired_body.py')
summary=dict(source_commit=r['current_commit'],complete=True,passed=False,full_reference_qualified=False,
    added_mass_reference_qualified=False,elapsed_seconds=r['elapsed_seconds'],
    actual_panels=[x['panels'] for x in r['levels']],completed_capytaine_calls=24,completed_topwater_levels=4,
    gates=r['gates'],failed_entries=r['failed_entries'],odd_parity=r['maximum_odd_parity_normalized'],
    maximum_trace_operator_ratio=max(x for row in r['trace_checks'] for key,x in row.items() if key!='level'),
    maximum_archived_load_reconstruction_ratio=max(ratios),
    capytaine_diagonals=a['capytaine_Ainf'].diagonal(axis1=1,axis2=2).tolist(),
    topwater_diagonals=a['topwater_Ainf'].diagonal(axis1=1,axis2=2).tolist(),
    geometry=reports[cases[2]]['levels'],localization=local['diagnostics'],
    interpretation=local['interpretation'],
    preserved_attempt='Study001 incomplete AttributeError before Capytaine calls; corrected freeze numerical arrays are bitwise equal',
    shared_input_bindings=shared,tests=checks,bundle_sha256=digest(bundle),
    next='Frozen-coarse-Capytaine-source pressure quadrature diagnostic; exact telescoping with unresolved remainder, no remesh/optimization or promotion')
bundle.with_name('paired-body-001-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(bundle=str(bundle),bytes=bundle.stat().st_size,sha256=summary['bundle_sha256'],tests=checks),indent=2))
