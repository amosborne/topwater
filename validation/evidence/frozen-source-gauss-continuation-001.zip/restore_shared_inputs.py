from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import argparse,json,shutil
p=argparse.ArgumentParser();p.add_argument('--reuse-bundle',type=Path,required=True);args=p.parse_args()
root=Path(__file__).resolve().parent
spec=json.loads((root/'shared-inputs.json').read_text());external=spec['external'];shared=spec['shared']
assert sha256(args.reuse_bundle.read_bytes()).hexdigest()==external['sha256']
def target(entry):
    out=(root/entry).resolve();assert out.is_relative_to(root);out.parent.mkdir(parents=True,exist_ok=True);return out
out=target(external['copy_to']);shutil.copyfile(args.reuse_bundle,out)
with ZipFile(args.reuse_bundle) as z:payload=z.read(external['extract_entry'])
assert sha256(payload).hexdigest()==external['parent_sha256']
for entry in external['parent_targets']:target(entry).write_bytes(payload)
payload=root/shared['payload_entry'];assert sha256(payload.read_bytes()).hexdigest()==shared['sha256']
shutil.copyfile(payload,target(shared['copy_to']))
print('External SHA-pinned historical bundle and all shared inputs restored.')
