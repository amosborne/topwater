from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED,ZIP_STORED
import json,xml.etree.ElementTree as ET
import numpy as np
from topwater.rankine import TrianglePanels
from tests.validation.common import read_owned,digest,current_sources,mesh_quality
from tests.validation.finest_consumer import stream_hash
from tests.validation.frozen_source_quadrature import pressure_matrix
from tests.validation.paired_body import scaled_check

root=Path('artifacts/validation');stem='fixed-infinity-pilot-001';path=root/(stem+'.json')
r,a=read_owned(path,digest('validation/fixed-infinity-pilot-controls.json'),'fixed-seed-infinity-pilot');current_sources(r,tuple(r['producer_sha256']))
assert r['complete'] and not r['passed'] and r['source_export_verified'] and r['completed_capytaine_calls']==6 and r['completed_orders']==3
assert not r['synthetic_fields'] and not r['resource_only'] and not r['full_reference_qualified'] and not r['source_discretization_qualified']
assert r['elapsed_seconds']<=600 and r['accounted_disk_upper_bytes']<=2*1024**3
assert max(r['latest_memory'][key] for key in ('peak_working_set_bytes','peak_committed_bytes'))<=2*1024**3
scale=np.sqrt(a['dry_mass'].diagonal()[:,None]*a['dry_mass'].diagonal()[None,:]);panels=TrianglePanels(a['source_triangles'],-1)
native=pressure_matrix(a['native_points'],panels.normals,panels.areas,a['native_potential'],a['world_cg'],1025.)
ratios=[scaled_check(native,a['native_Ainf'],scale,1e-10),scaled_check(native,a['original_native_Ainf'],scale,1e-10)]
np.testing.assert_array_equal(a['operator_potential']-a['native_potential'],a['potential_residual'])
np.testing.assert_array_equal(a['operator_normal']-a['native_boundary'],a['normal_residual'])
for order in (12,16,20):
    prefix=f'order_{order}_';key=f'target_{order}_'
    A=pressure_matrix(a[key+'points'],a[key+'normal'],a[key+'weights'],a[prefix+'potential'],a['world_cg'],1025.)
    ratios.append(scaled_check(A,a[prefix+'A_complex'],scale,1e-10))
U,gate=mesh_quality(a['quadrature_A']/scale,dict(reference_mesh_relative=.001,reference_mesh_absolute_normalized=1e-6))
assert gate==r['quadrature_stabilization'] and r['pilot_passed']==gate['passed'];np.testing.assert_array_equal(U*scale,a['quadrature_uncertainty'])
previous=abs(a['quadrature_A'][1]-a['quadrature_A'][0])/scale;latest=abs(a['quadrature_A'][2]-a['quadrature_A'][1])/scale;allow=1e-6+.001*abs(a['quadrature_A'][2]/scale)
for key,value in [('previous_ratio',previous/allow),('latest_ratio',latest/allow),('previous_failed',previous>allow),('latest_failed',latest>allow),('trend_failed',latest>previous+1e-6)]:np.testing.assert_array_equal(value,a[key])
payload=path.with_suffix('.payload.zip')
with payload.open('rb') as file:assert stream_hash(file)==r['payload_package']['sha256']
with ZipFile(payload) as z:
    assert z.testzip() is None
    with z.open('arrays.npz') as file:assert stream_hash(file)==r['arrays_sha256']
archive=path.with_suffix('.source')
with ZipFile(archive/'preflight.zip') as z:oldspec=json.loads(z.read('external-inputs.json'))
external=[]
for item in oldspec:
    item['copy_to']=['validation/'+stem+'.source/'+item['argument']+'.zip'];external.append(item)
    assert digest(archive/(item['argument']+'.zip'))==item['sha256']
restore='''from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import argparse,json,shutil
p=argparse.ArgumentParser()
for name in ('frozen','raw','sources'):p.add_argument('--'+name+'-bundle',type=Path,required=True)
args=p.parse_args();root=Path(__file__).resolve().parent;stem='fixed-infinity-pilot-001'
r=json.loads((root/'validation'/(stem+'.json')).read_text());payload=root/'validation'/(stem+'.payload.zip')
def digest(file):
    h=sha256()
    with file.open('rb') as stream:
        while chunk:=stream.read(1048576):h.update(chunk)
    return h.hexdigest()
def target(entry):
    out=(root/entry).resolve();assert out.is_relative_to(root);out.parent.mkdir(parents=True,exist_ok=True);return out
assert digest(payload)==r['payload_package']['sha256']
with ZipFile(payload) as z:
    with z.open('arrays.npz') as source,target('validation/'+stem+'.npz').open('wb') as dest:shutil.copyfileobj(source,dest)
    for item in z.infolist():
        if item.filename.startswith('source/') and not item.is_dir():
            out=target('validation/'+stem+'.source/'+item.filename[len('source/'):])
            with z.open(item) as source,out.open('wb') as dest:shutil.copyfileobj(source,dest)
assert digest(root/'validation'/(stem+'.npz'))==r['arrays_sha256']
for item in json.loads((root/'external-inputs.json').read_text()):
    source=getattr(args,item['argument']+'_bundle');assert digest(source)==item['sha256']
    for entry in item['copy_to']:shutil.copyfile(source,target(entry))
print('Actual infinite-source pilot NPZ/source/payload and all exact inputs restored. One-mesh scope retained.')
'''
junit=Path('artifacts/pytest-fixed-pilot-all-002.xml');suites=ET.parse(junit).findall('.//testsuite');checks={key:sum(int(x.attrib.get(key,0)) for x in suites) for key in ('tests','failures','errors','skipped')};assert checks==dict(tests=288,failures=0,errors=0,skipped=0)
bundle=Path('validation/evidence/fixed-infinity-pilot-001.zip');assert not bundle.exists()
with ZipFile(bundle,'x',ZIP_DEFLATED) as z:
    z.write(path,'validation/'+stem+'.json');z.write(payload,'validation/'+stem+'.payload.zip',compress_type=ZIP_STORED)
    z.writestr('external-inputs.json',json.dumps(external,indent=2)+'\n');z.writestr('restore_inputs.py',restore)
    z.writestr('README.txt','Actual one-mesh Ainf source/output pilot. After extraction run python restore_inputs.py --frozen-bundle PATH --raw-bundle PATH --sources-bundle PATH using tracked input archives. NPZ/source graph restored from immutable payload. Full/source-mesh/finite-wave qualification remains false.\n')
    z.write(junit,'checks/'+junit.name);z.write(__file__,'pack_fixed_infinity_pilot.py')
assert bundle.stat().st_size<100*1024**2
summary={key:r[key] for key in ('current_commit','complete','passed','pilot_passed','source_export_verified','completed_capytaine_calls','completed_orders','source_checks','source_export_seconds','orders','quadrature_stabilization','pristine_operators','trace_normalization','auxiliary_potential_units','memory_records','latest_memory','accounted_disk_upper_bytes','elapsed_seconds','payload_package','interpretation')}
summary.update(bundle_sha256=digest(bundle),external_inputs=external,tests=checks,maximum_load_reconstruction_ratio=max(ratios),
    native_diagonal=a['native_Ainf'].diagonal().tolist(),quadrature_diagonals=a['quadrature_A'].diagonal(axis1=1,axis2=2).tolist(),
    output_change_diagonal=a['output_change'].diagonal().tolist(),failure_entries={key:np.argwhere(a[key]).tolist() for key in ('previous_failed','latest_failed','trend_failed')})
bundle.with_name('fixed-infinity-pilot-001-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(bundle=str(bundle),bytes=bundle.stat().st_size,sha256=summary['bundle_sha256']),indent=2))
