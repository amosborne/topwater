"""Preserve completed unqualified field/map evidence and sampling diagnosis."""
import json
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import numpy as np
from tests.validation.common import read_owned,digest,current_sources
from tests.validation.periodic_grid import exterior_points,check_surface

root=Path('artifacts/validation');stem='periodic-fields-001';path=root/(stem+'.json')
r,a=read_owned(path,digest('validation/periodic-grid-controls.json'),'periodic-field-map-candidate')
current_sources(r,tuple(r['producer_sha256']))
assert r['complete'] and not r['passed'] and r['completed_component_evaluations']==12
assert not r['full_reference_qualified'] and not r['nonlinear_restart_ready']
assert not r['original_raw_passed'] and r['elapsed_seconds']<=1800
assert a['potential_phasors'].shape==(4,3,8,138)
assert all(np.isfinite(v).all() for v in a.values())
exterior_points(a['reference_points'],a['mean_hull_planes'])
np.testing.assert_allclose(a['elevation_phasors'],1j*a['angular_frequencies_rad_s'][None,:,None,None]*a['potential_phasors']/r['gravity_m_s2'],atol=0,rtol=1e-15)
np.testing.assert_array_equal(a['initial_elevation'],a['elevation_phasors'][-1].sum(axis=0).real)
np.testing.assert_array_equal(a['initial_potential'],a['potential_phasors'][-1].sum(axis=0).real)
for entry in r['surface_maps']:
    assert entry['geometry_passed'];pre='scale_'+str(entry['amplitude_scale'])+'_'
    check_surface(a[pre+'vertices'],a[pre+'faces'],a[pre+'hull_planes'],entry['contact_vertices'])
d,da=read_owned(root/'field-sampling-001.json',digest('validation/periodic-grid-controls.json'),'periodic-field-sampling-diagnostic')
assert d['input_manifest_sha256']==digest(path) and d['input_arrays_sha256']==digest(path.with_suffix('.npz'))
bundle=Path('validation/evidence')/(stem+'.zip');assert not bundle.exists()
with ZipFile(bundle,'x',ZIP_DEFLATED) as z:
    for name in (stem,'field-sampling-001'):
        for suffix in ('.json','.npz'):z.write(root/(name+suffix),'validation/'+name+suffix)
        for p in sorted((root/(name+'.source')).rglob('*')):
            if p.is_file():z.write(p,'validation/'+name+'.source/'+p.relative_to(root/(name+'.source')).as_posix())
    z.write(__file__,'pack_periodic_fields.py')
summary={k:r[k] for k in ('current_commit','complete','passed','completed_component_evaluations','elapsed_seconds',
    'full_reference_qualified','nonlinear_restart_ready','original_raw_passed','field_diagnostics','surface_maps',
    'required_readiness','qualification_status','case_sha256','protocol_sha256','source_bundle_sha256')}
summary.update(bundle_sha256=digest(bundle),eta0_range_m=[float(a['initial_elevation'].min()),float(a['initial_elevation'].max())],
    phi0_range_m2_s=[float(a['initial_potential'].min()),float(a['initial_potential'].max())],
    angular_decomposition=d['diagnostics'],
    runtime_status='No Topwater coupled time-domain run or speed qualification',
    interpretation='Geometry passed. Field diagnostics failed non-monotonic trends and total-field angular representation; known incident waves dominate far-grid interpolation. No relaxation or complete initialization claim.')
bundle.with_name(stem+'-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(bundle=str(bundle),sha256=summary['bundle_sha256'],bytes=bundle.stat().st_size,
    complete=r['complete'],passed=r['passed'],eta0_range_m=summary['eta0_range_m']),indent=2))
