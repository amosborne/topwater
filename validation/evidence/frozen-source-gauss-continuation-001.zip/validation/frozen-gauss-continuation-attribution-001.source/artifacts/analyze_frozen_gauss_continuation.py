from pathlib import Path
import json,shutil
import numpy as np
from tests.validation.common import prepare,save,read_owned,digest,current_sources

p=Path('artifacts/validation/frozen-source-gauss-continuation-001.json')
contract=Path('validation/frozen-source-gauss-continuation-controls.json')
r,a=read_owned(p,digest(contract),'frozen-source-pressure-quadrature')
current_sources(r,tuple(r['producer_sha256']))
output=Path('artifacts/validation/frozen-gauss-continuation-attribution-001.json')
report=prepare(output,contract,'frozen-quadrature-attribution');out={};archive=output.with_suffix('.source')
relative=Path(__file__).resolve().relative_to(Path.cwd());target=archive/relative
target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(relative,target)
report['producer_sha256'][relative.as_posix()]=digest(relative)
for suffix in ('.json','.npz'):shutil.copyfile(p.with_suffix(suffix),archive/('quadrature'+suffix))
for name in ('inputs.json','parent.zip'):shutil.copyfile(p.with_suffix('.source')/name,archive/name)
report.update(parent_manifest_sha256=digest(p),parent_arrays_sha256=digest(p.with_suffix('.npz')),
    parent_bundle_sha256=r['parent_bundle_sha256'],input_sha256=r['input_sha256'],
    full_reference_qualified=False,scope='Signed measured attribution; no pure-source or continuum error inference')
save(output,report,out)
for level in range(4):
    for name in ('measured_total_increment','output_quadrature_change','unresolved_remainder'):
        value=a[f'level{level}_'+name]
        out[f'level{level}_'+name]=value;out[f'level{level}_'+name+'_absolute']=abs(value)
    O=a[f'level{level}_output_quadrature_change'].real;R=a[f'level{level}_unresolved_remainder'].real
    out[f'level{level}_opposed_components']=(O*R)<0
for key in ('previous_ratio','latest_ratio'):
    out[key]=a[key];out[key+'_failed']=a[key]>1
out['trend_failed']=a['trend_failed']
report.update(complete=True,passed=False,opposed_final_entries=np.argwhere(out['level3_opposed_components']).tolist(),
    output_change_diagonal=a['level3_output_quadrature_change'].real.diagonal().tolist(),
    remainder_diagonal=a['level3_unresolved_remainder'].real.diagonal().tolist())
save(output,report,out);print(json.dumps({k:report[k] for k in ('opposed_final_entries','output_change_diagonal','remainder_diagonal')}))
