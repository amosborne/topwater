"""Archive a terminal recovery with its complete immutable dependency graph."""
import json
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import numpy as np
from tests.validation.common import read_owned,digest,current_sources
from tests.validation.periodic_sources import combine,integrate_pressure,require_close,rigid_normal_modes

root=Path('artifacts/validation');stem='periodic-sources-003';path=root/(stem+'.json')
r,a=read_owned(path,digest('validation/periodic-source-controls.json'),'periodic-source-recovery',passed=True)
current_sources(r,tuple(r['producer_sha256']))
assert r['completed_physics_calls']==84 and len(r['checks'])==384
assert not r['full_reference_qualified'] and not r['nonlinear_restart_ready']
assert not r['original_raw_passed'] and r['elapsed_seconds']<=1800
assert len(r['levels'])==4 and all(x['complete'] for x in r['levels'])
for row in r['levels']:
    pre=f'level{row["level"]}_';n=row['panels'];t=a[pre+'triangles']
    assert t.shape==(n,3,3)
    for key in ('sources','potential','pressure','normal_velocity','source_potential','source_normal_velocity'):
        assert a[pre+key].shape==(3,n,7) and np.isfinite(a[pre+key]).all()
    for f,w in enumerate(a['angular_frequencies_rad_s']):
        i=row['level']-1;z=a['incident_phasors_m'][f];xi=a['raw_RAO'][i,f,f]*z
        np.testing.assert_array_equal(a[pre+'scattered_sources'][f],combine(a[pre+'sources'][f],z,xi))
        require_close(a[pre+'source_potential'][f],a[pre+'potential'][f],1,1e-12,1e-12)
        require_close(a[pre+'source_normal_velocity'][f],a[pre+'normal_velocity'][f],1,1e-12,1e-12)
        require_close(a[pre+'total_hull_normal_velocity'][f],-1j*w*(rigid_normal_modes(t,a['world_cg'])@xi),1,1e-12,1e-12)
out=Path('validation/evidence');bundle=out/(stem+'.zip')
assert not bundle.exists()
with ZipFile(bundle,'x',ZIP_DEFLATED) as z:
    for failed in ('periodic-sources-001','periodic-sources-002'):
        for suffix in ('.json','.npz'):
            z.write(root/(failed+suffix),'validation/'+failed+suffix)
        for p in sorted((root/(failed+'.source')).rglob('*')):
            if p.is_file():z.write(p,'validation/'+failed+'.source/'+p.relative_to(root/(failed+'.source')).as_posix())
    for suffix in ('.json','.npz'):z.write(path.with_suffix(suffix),'validation/'+stem+suffix)
    for p in sorted(path.with_suffix('.source').rglob('*')):
        if p.is_file():z.write(p,'validation/'+stem+'.source/'+p.relative_to(path.with_suffix('.source')).as_posix())
    z.write(__file__,'pack_periodic_sources.py')
summary={k:r[k] for k in ('current_commit','complete','passed','completed_physics_calls','elapsed_seconds',
    'full_reference_qualified','nonlinear_restart_ready','original_raw_passed','qualification_scope',
    'density_kg_m3','gravity_m_s2','water_depth','forward_speed_m_s','time_convention','basis_columns',
    'basis_normalization','source_convention','trace_units','mesh_normals','case_sha256','protocol_sha256','raw_bundle_sha256')}
summary.update(bundle_sha256=digest(bundle),checks=len(r['checks']),
    maximum_reproduction_tolerance_ratio=max(x['maximum_tolerance_ratio'] for x in r['checks']),
    interrupted_001='Native initialization interrupted for review corrections; 0 completed physics calls; terminal exit1',
    rejected_002='AxisError from symbolic DOFs; 0 completed physics calls; terminal exit1',
    runtime_status='No Topwater coupled TD run or speed measurement',
    next='Admissible reference-to-nonlinear geometry map/grid; field uncertainty and compatibility; then actual coupled cost screen')
(out/(stem+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
